import { Users, Check } from "lucide-react";

const O_QUE_MUDA = [
  "Mesma versão do contrato para a PME e o cliente, no mesmo ambiente.",
  "Histórico de negociação visível para todos os envolvidos, sem assimetria.",
  "Combinados informais formalizados, com aprovação documentada.",
  "Quando algo é questionado, a evidência aparece na hora."
];

export function Pilar01Colaborativo() {
  return (
    <section className="relative bg-white">
      <div className="container-soma section-soma">
        {/* Header do pilar */}
        <div className="mb-12 max-w-[860px]">
          <div
            className="mb-5 inline-flex items-center gap-2 rounded-full border px-3 py-1.5"
            style={{
              background: "var(--peach-bg)",
              borderColor: "rgba(212,148,90,0.4)"
            }}
          >
            <span
              className="font-mono text-[10px] font-bold tracking-widest"
              style={{ color: "var(--peach-dark)" }}
            >
              PILAR 01
            </span>
            <span className="h-3 w-px bg-peach-dark/40" />
            <Users className="size-4 text-peach-dark" strokeWidth={2} />
            <span
              className="font-mono text-[11px] font-bold uppercase tracking-widest"
              style={{ color: "var(--peach-dark)" }}
            >
              Para PMEs sem time jurídico
            </span>
          </div>

          <h2 className="h-soma mb-4">
            Um ambiente colaborativo de contratos, onde todos os envolvidos
            veem a mesma versão ao mesmo tempo.
          </h2>

          <p className="text-lg leading-relaxed text-gray-700">
            Diferente das ferramentas de gestão de contratos que vivem dentro
            do sistema de uma das partes, a +legal_ funciona como um ambiente
            comum entre quem participa do contrato. A versão é a mesma para
            todos, atualizada em tempo real, e o histórico fica em um lugar
            só,
            sem cópias paralelas espalhadas por drives e e-mails.
          </p>
        </div>

        {/* Layout principal · 2 colunas: visual à esquerda, conteúdo à direita */}
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_1.1fr] lg:gap-14">
          {/* Visual · ambiente compartilhado */}
          <div className="order-2 lg:order-1">
            <VisualAmbiente />
          </div>

          {/* Conteúdo · cenário + lista */}
          <div className="order-1 flex flex-col gap-6 lg:order-2">
            {/* Cenário típico */}
            <div
              className="rounded-2xl border-2 p-6 md:p-7"
              style={{
                borderColor: "var(--peach-dark)",
                background: "var(--peach-bg)"
              }}
            >
              <div className="mb-3 flex items-center gap-2">
                <span
                  className="font-mono text-[10px] font-bold uppercase tracking-widest"
                  style={{ color: "var(--peach-dark)" }}
                >
                  Cenário típico
                </span>
                <span className="h-3 w-px bg-peach-dark/40" />
                <span
                  className="font-mono text-[10px] font-bold uppercase tracking-widest"
                  style={{ color: "var(--peach-dark)" }}
                >
                  Sócia-fundadora de PME
                </span>
              </div>

              <p className="font-title text-base leading-relaxed text-gray-900 md:text-lg">
                Agência de marketing com 12 pessoas. Cliente corporativo de
                R$80k por ano. Cláusulas de confidencialidade, KPIs mensais,
                marcos de entrega. Do outro lado da mesa, um departamento
                jurídico estruturado, com mais histórico, mais informação, mais
                recurso.
              </p>
            </div>

            {/* O que muda na prática */}
            <div className="rounded-2xl border border-stone-200 bg-white p-6 md:p-7">
              <p
                className="mb-4 font-mono text-[10px] font-bold uppercase tracking-widest"
                style={{ color: "var(--peach-dark)" }}
              >
                O que muda na prática
              </p>
              <ul className="flex flex-col gap-3">
                {O_QUE_MUDA.map(item => (
                  <li key={item} className="flex items-start gap-3">
                    <span
                      className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full"
                      style={{ background: "var(--peach-bg)" }}
                    >
                      <Check
                        className="size-3 text-peach-dark"
                        strokeWidth={3}
                      />
                    </span>
                    <span className="text-[15px] leading-snug text-gray-700">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Visual · 2 lados acessando o mesmo contrato AO MESMO TEMPO
function VisualAmbiente() {
  return (
    <div className="relative h-full min-h-[440px] overflow-hidden rounded-3xl border border-stone-200 bg-stone-50 p-8 lg:p-10">
      <svg
        viewBox="0 0 480 460"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-full"
        aria-hidden="true"
      >
        {/* ═════ Cliente Corporativo · canto superior esquerdo ═════ */}
        <g transform="translate(80 80)">
          <rect
            x="-50"
            y="-30"
            width="100"
            height="60"
            rx="8"
            fill="white"
            stroke="var(--brand)"
            strokeWidth="1.6"
          />
          <text
            x="0"
            y="-8"
            fontFamily="JetBrains Mono, monospace"
            fontSize="9"
            fontWeight="700"
            fill="var(--brand)"
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.6"
          >
            CLIENTE
          </text>
          <text
            x="0"
            y="6"
            fontFamily="Barlow, sans-serif"
            fontSize="13"
            fontWeight="800"
            fill="var(--brand)"
            textAnchor="middle"
          >
            Corporativo
          </text>
          <text
            x="0"
            y="20"
            fontFamily="JetBrains Mono, monospace"
            fontSize="8"
            fontWeight="500"
            fill="var(--brand)"
            textAnchor="middle"
            letterSpacing="1"
            opacity="0.5"
          >
            JURÍDICO + COMPRAS
          </text>

          {/* Marcador "ativo" · azul (sem animação) */}
          <g transform="translate(46 -26)">
            <circle r="3.5" fill="var(--brand)" />
            <circle r="1.4" fill="white" />
          </g>
        </g>

        {/* ═════ PME · canto inferior esquerdo ═════ */}
        <g transform="translate(80 380)">
          <rect
            x="-50"
            y="-30"
            width="100"
            height="60"
            rx="8"
            fill="white"
            stroke="var(--peach-dark)"
            strokeWidth="1.6"
          />
          <text
            x="0"
            y="-8"
            fontFamily="JetBrains Mono, monospace"
            fontSize="9"
            fontWeight="700"
            fill="var(--peach-dark)"
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.6"
          >
            PME
          </text>
          <text
            x="0"
            y="6"
            fontFamily="Barlow, sans-serif"
            fontSize="13"
            fontWeight="800"
            fill="var(--peach-dark)"
            textAnchor="middle"
          >
            Agência
          </text>
          <text
            x="0"
            y="20"
            fontFamily="JetBrains Mono, monospace"
            fontSize="8"
            fontWeight="500"
            fill="var(--peach-dark)"
            textAnchor="middle"
            letterSpacing="1"
            opacity="0.5"
          >
            12 PESSOAS
          </text>

          {/* Marcador "ativo" · peach (sem animação) */}
          <g transform="translate(46 -26)">
            <circle r="3.5" fill="var(--peach-dark)" />
            <circle r="1.4" fill="white" />
          </g>
        </g>

        {/* ═════ Linhas conectando as duas pontas ao contrato ═════ */}
        <path
          d="M 130 80 Q 240 130 320 200"
          stroke="var(--brand)"
          strokeWidth="1.5"
          strokeDasharray="4 4"
          fill="none"
          opacity="0.5"
        />
        <path
          d="M 130 380 Q 240 330 320 260"
          stroke="var(--peach-dark)"
          strokeWidth="1.5"
          strokeDasharray="4 4"
          fill="none"
          opacity="0.5"
        />

        {/* ═════ Contrato central · documento compartilhado ═════ */}
        <g transform="translate(360 230)">
          {/* Documento */}
          <rect
            x="-72"
            y="-100"
            width="144"
            height="200"
            rx="8"
            fill="white"
            stroke="var(--brand)"
            strokeWidth="2"
          />

          {/* Header do documento · "Atualizado agora" */}
          <rect
            x="-72"
            y="-100"
            width="144"
            height="22"
            rx="8"
            fill="var(--brand-tint)"
          />
          <rect
            x="-72"
            y="-86"
            width="144"
            height="8"
            fill="var(--brand-tint)"
          />
          {/* Marcador "ativo" · azul, sem animação */}
          <circle cx="-58" cy="-89" r="2.5" fill="var(--brand)" />
          <text
            x="-48"
            y="-86"
            fontFamily="JetBrains Mono, monospace"
            fontSize="7"
            fontWeight="700"
            fill="var(--brand)"
            letterSpacing="1"
          >
            ATUALIZADO AGORA
          </text>
          <text
            x="50"
            y="-86"
            fontFamily="JetBrains Mono, monospace"
            fontSize="7"
            fontWeight="700"
            fill="var(--brand)"
            textAnchor="end"
            letterSpacing="0.5"
            opacity="0.55"
          >
            v.07
          </text>

          {/* Linhas de texto do documento */}
          {[-66, -56, -46, -36, -26, -16, -6, 4, 14, 24, 34, 44, 54].map(y => (
            <line
              key={y}
              x1="-58"
              y1={y}
              x2={y % 20 === 0 ? "50" : "44"}
              y2={y}
              stroke="var(--brand)"
              strokeWidth="1"
              opacity="0.22"
              strokeLinecap="round"
            />
          ))}

          {/* Highlight de seleção do CLIENTE · linha azul destacada */}
          <rect
            x="-60"
            y="-30"
            width="80"
            height="9"
            rx="2"
            fill="var(--brand)"
            opaci