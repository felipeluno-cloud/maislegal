import { HeroIllustration1 } from "@/components/home/HeroIllustration1";
import { HeroIllustration2 } from "@/components/home/HeroIllustration2";
import { HeroIllustration3 } from "@/components/home/HeroIllustration3";

const OPCOES = [
  {
    num: "01",
    title: "Timeline vertical animada",
    desc: "Stack vertical com 5 etapas numeradas. Linha conectora com gradiente. Cada etapa entra com fade-in sequencial. SOMA destacada como última, com badge 'O diferencial'. Texto sempre alinhado horizontal, fácil de ler.",
    pros: "Texto alinhado · Lê de cima a baixo · Compacto · Animação sutil",
    cons: "Mais 'lista' do que 'visual marcante'",
    Component: HeroIllustration1
  },
  {
    num: "02",
    title: "Workspace mockup minimalista",
    desc: "Simula a UI do produto: top bar, stats, alerta animado, lista de contratos. Badge floating 'Câmara acoplada' com ring pulsante. Stats animam entrando da esquerda, alerta da direita.",
    pros: "Parece produto real · Mostra a plataforma · Animações dinâmicas",
    cons: "Pode parecer 'mockup demais' · Mais info pra ler"
  },
  {
    num: "03",
    title: "Documento vivo + badges flutuantes",
    desc: "Documento central com breathing animation, status verde pulsante. 4 badges floating ao redor (alerta, aditivo, histórico, SOMA), cada um com animação float em tempos diferentes. SOMA destacada embaixo com glow.",
    pros: "Documento como protagonista · SOMA com peso visual claro · Movimento delicado",
    cons: "Mais elementos · Pode distrair"
  }
];

export default function HeroOptionsPage() {
  return (
    <div className="bg-stone-50 min-h-screen py-16">
      <div className="container-soma">
        <div className="mb-12 max-w-[820px]">
          <p className="eyebrow mb-4">Teste de ilustrações</p>
          <h1 className="h-soma-lg mb-4">3 opções de ilustração para o Hero.</h1>
          <p className="text-lg text-gray-600">
            Cada uma tem animações sutis (CSS only). Clica no botão da Home pra ver no contexto, mas aqui dá pra comparar lado a lado.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
          {/* OPÇÃO 1 */}
          <div className="flex flex-col gap-5">
            <div className="rounded-xl border-2 border-brand bg-white p-5">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-brand text-white font-mono font-bold">
                  01
                </div>
                <h2 className="font-title text-xl font-bold text-gray-900">
                  Timeline vertical
                </h2>
              </div>
              <p className="mb-3 text-sm leading-relaxed text-gray-700">
                Stack vertical com 5 etapas numeradas. Linha conectora com
                gradiente. Cada etapa entra com fade-in sequencial. SOMA destacada
                com badge.
              </p>
              <div className="border-t border-stone-200 pt-3">
                <p className="font-mono text-[10px] font-bold uppercase tracking-widest text-emerald-700">
                  ✓ Texto alinhado · Lê de cima a baixo · Compacto
                </p>
                <p className="mt-1 font-mono text-[10px] font-bold uppercase tracking-widest text-stone-500">
                  ⚠ Mais "lista" do que "visual marcante"
                </p>
              </div>
            </div>
            <div className="rounded-xl bg-white p-6">
              <HeroIllustration1 />
            </div>
          </div>

          {/* OPÇÃO 2 */}
          <div className="flex flex-col gap-5">
            <div className="rounded-xl border-2 border-peach-dark bg-white p-5">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-peach-dark text-white font-mono font-bold">
                  02
                </div>
                <h2 className="font-title text-xl font-bold text-gray-900">
                  Workspace mockup
                </h2>
              </div>
              <p className="mb-3 text-sm leading-relaxed text-gray-700">
                Simula a UI do produto. Top bar, stats, alerta animado, lista
                de contratos. Badge floating "Câmara acoplada" com ring
                pulsante.
              </p>
              <div className="border-t border-stone-200 pt-3">
                <p className="font-mono text-[10px] font-bold uppercase tracking-widest text-emerald-700">
                  ✓ Parece produto real · Mostra a plataforma
                </p>
                <p className="mt-1 font-mono text-[10px] font-bold uppercase tracking-widest text-stone-500">
                  ⚠ Pode parecer "mockup demais"
                </p>
              </div>
            </div>
            <div className="rounded-xl bg-white p-6">
              <HeroIllustration2 />
            </div>
          </div>

          {/* OPÇÃO 3 */}
          <div className="flex flex-col gap-5">
            <div className="rounded-xl border-2 border-soma bg-white p-5">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-soma text-white font-mono font-bold">
                  03
                </div>
                <h2 className="font-title text-xl font-bold text-gray-900">
                  Documento vivo
                </h2>
              </div>
              <p className="mb-3 text-sm leading-relaxed text-gray-700">
                Documento central com breathing. Status verde pulsante. 4
                badges floating ao redor (alerta, aditivo, histórico, SOMA),
                cada um com float em tempos diferentes.
              </p>
              <div className="border-t border-stone-200 pt-3">
                <p className="font-mono text-[10px] font-bold uppercase tracking-widest text-emerald-700">
                  ✓ Documento protagonista · SOMA com peso · Movimento delicado
                </p>
                <p className="mt-1 font-mono text-[10px] font-bold uppercase tracking-widest text-stone-500">
                  ⚠ Mais elementos · Pode distrair
                </p>
              </div>
            </div>
            <div className="rounded-xl bg-white p-6">
              <HeroIllustration3 />
            </div>
          </div>
        </div>

        <div className="mt-16 rounded-2xl border-2 border-brand bg-brand-tint p-8 text-center">
          <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
            Próximo passo
          </p>
          <h2 className="mb-3 font-title text-2xl font-bold text-gray-900">
            Qual aplicar no Hero da Home?
          </h2>
          <p className="text-base text-gray-700">
            Diz qual número (01, 02 ou 03) e eu troco no Hero.tsx. Ou pode
            misturar elementos de duas opções.
          </p>
        </div>
      </div>
    </div>
  );
}
