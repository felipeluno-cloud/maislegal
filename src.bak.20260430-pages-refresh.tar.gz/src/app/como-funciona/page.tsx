import {
  ArrowRight,
  Upload,
  MessageSquare,
  Bell,
  FilePlus,
  Scale,
  Cog,
  Plug,
  Users,
  Activity,
  Layers,
  Briefcase,
  Building2,
  FileSearch,
  HandshakeIcon,
  Gift,
  Sparkles,
  Heart
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/base/Button";
import { CtaDark } from "@/components/base/CtaDark";
import { Accordion } from "@/components/base/Accordion";

// 6 etapas do contrato, alinhadas com o Pilar 02 da home
const CICLO = [
  {
    num: "01",
    label: "Rascunho",
    body: "A minuta nasce dentro do ambiente, com templates pré-aprovados ou com upload de um contrato existente."
  },
  {
    num: "02",
    label: "Negociação",
    body: "As partes editam o documento em conjunto, comentam cláusulas, registram contrapropostas, e cada movimento fica com data e autoria."
  },
  {
    num: "03",
    label: "Assinatura",
    body: "Integração nativa com as principais plataformas do mercado, sem trocar de ferramenta no momento da assinatura."
  },
  {
    num: "04",
    label: "Cumprimento",
    body: "Cada cláusula vira obrigação rastreável, com alertas automáticos antes de cada prazo, vencimento ou janela de renovação."
  },
  {
    num: "05",
    label: "Aditivos",
    body: "Mudanças e concessões são formalizadas dentro do mesmo ambiente, com aprovação documentada das partes envolvidas."
  },
  {
    num: "06",
    label: "Resolução",
    body: "Se uma disputa acontecer, a câmara SOMA está acoplada e o histórico do contrato vai junto, sem reconstrução."
  }
];

// Storyboard de 5 momentos de uso real
const STORYBOARD = [
  {
    num: "01",
    when: "No primeiro dia",
    icon: Upload,
    title: "O contrato sobe na plataforma.",
    body: "Você sobe um contrato existente ou cria a partir de templates pré-aprovados, e convida a outra parte como visitante, sem custo. A partir desse momento, o documento deixa de viver em e-mails e drives separados, e passa a existir em um ambiente só.",
    color: "brand"
  },
  {
    num: "02",
    when: "Durante a negociação",
    icon: MessageSquare,
    title: "Cada concessão fica documentada.",
    body: "As cláusulas são comentadas no próprio contrato, com versões registrando quem alterou o quê, e cada contraproposta tem data e autoria. O combinado fica por escrito desde o começo, e não sobra espaço para 'eu lembro diferente'.",
    color: "brand"
  },
  {
    num: "03",
    when: "No dia a dia",
    icon: Bell,
    title: "Os alertas chegam antes do problema.",
    body: "A plataforma transforma cada cláusula em obrigação rastreável, e os alertas automáticos chegam 30, 60 ou 90 dias antes de qualquer vencimento, renovação ou marco contratual. Nenhum prazo passa batido, mesmo se quem cuidava do contrato sair da empresa.",
    color: "peach"
  },
  {
    num: "04",
    when: "Quando algo muda",
    icon: FilePlus,
    title: "O ajuste vira aditivo, não conversa solta.",
    body: "Uma concessão combinada por WhatsApp ou em reunião pode ser formalizada como aditivo em poucos minutos, com aprovação documentada das duas partes. O contrato continua refletindo o que foi acordado de verdade, sem deixar pontas soltas para o futuro.",
    color: "peach"
  },
  {
    num: "05",
    when: "Se virar disputa",
    icon: Scale,
    title: "A câmara SOMA está do lado, pronta.",
    body: "Quando uma divergência não se resolve no diálogo, qualquer parte abre o procedimento na câmara SOMA com um clique, e o histórico inteiro do contrato é transferido automaticamente. A mediação vem primeiro, com incentivo financeiro, e a arbitragem entra só se a mediação não resolver.",
    color: "soma"
  }
];

// 4 diferenciais estruturais (após o Hero)
const DIFERENCIAIS = [
  {
    num: "01",
    title: "Ambiente colaborativo",
    kicker: "Para os dois lados, não para uma parte só.",
    body: "Não é o sistema interno do fornecedor nem do cliente. É um espaço comum entre quem participa do contrato, com a mesma versão e o mesmo histórico para todos os envolvidos.",
    visual: "colaborativo",
    color: "brand"
  },
  {
    num: "02",
    title: "Cuidado contínuo",
    kicker: "A plataforma não desliga depois da assinatura.",
    body: "A +legal_ acompanha o contrato justamente quando o resto do mercado já parou de prestar atenção. Cada cláusula vira obrigação rastreável, cada prazo recebe alerta automático, e o histórico fica vivo durante todo o ciclo.",
    visual: "continuo",
    color: "peach"
  },
  {
    num: "03",
    title: "Câmara acoplada",
    kicker: "A resolução começa onde o contrato vive.",
    body: "A SOMA está integrada à +legal_ por design, então uma disputa não exige sair do ambiente. O procedimento abre na câmara com um clique, o histórico do contrato é transferido automaticamente, e a mediação vem antes da arbitragem com incentivo financeiro embutido.",
    visual: "camara",
    color: "soma"
  },
  {
    num: "04",
    title: "Sem trocar a stack",
    kicker: "Encaixa no que você já usa.",
    body: "A +legal_ se conecta com a sua ferramenta de assinatura, o seu drive e o seu calendário, em vez de pedir para você abandonar nada do que já funciona. O que ela traz é a camada que faltava entre essas peças, no espaço onde o contrato vive de verdade.",
    visual: "stack",
    color: "brand"
  }
];

// 4 mockups da plataforma em uso
const MOCKUPS = [
  {
    icon: Layers,
    label: "Mockup 01",
    title: "O portfólio inteiro num lugar só.",
    body: "Você acompanha 47 contratos ativos em uma tela só, com status visual e indicação clara do que precisa de atenção primeiro. Renovações, aditivos pendentes e SLAs descumpridos aparecem consolidados em cards de stat no topo, antes mesmo de você abrir qualquer contrato.",
    visual: "portfolio",
    color: "brand"
  },
  {
    icon: MessageSquare,
    label: "Mockup 02",
    title: "Versões e comentários, todos no mesmo ambiente.",
    body: "Cada versão do contrato registra quem alterou o quê, com timestamp e autoria, e o histórico fica auditável desde o primeiro rascunho. Os comentários ficam ligados à cláusula que discutem, e não se perdem quando uma nova versão é publicada.",
    visual: "contrato",
    color: "brand"
  },
  {
    icon: Bell,
    label: "Mockup 03",
    title: "Cada obrigação rastreável, com alertas antes do prazo.",
    body: "O calendário mostra as próximas obrigações, vencimentos e janelas de renovação dos próximos 90 dias. Embaixo, a lista de alertas ativos vem ordenada por urgência, com responsável marcado e ação sugerida ao lado de cada item.",
    visual: "obrigacoes",
    color: "peach"
  },
  {
    icon: Scale,
    label: "Mockup 04",
    title: "Abertura de procedimento na câmara, com um clique.",
    body: "Quando uma divergência precisa virar disputa formal, o histórico do contrato é anexado automaticamente, sem reconstrução manual ou exportação para outro sistema. A mediação vem primeiro, com crédito do honorário se virar arbitragem, e tudo acontece dentro do mesmo ambiente.",
    visual: "soma",
    color: "soma"
  }
];

// 4 sinais de fit
const SINAIS_FIT = [
  {
    icon: Briefcase,
    body: "Você gerencia 50 ou mais contratos B2B ativos, com SLAs, prazos e obrigações que viram dor de cabeça operacional.",
    persona: "Para Operações",
    href: "/para-operacoes"
  },
  {
    icon: FileSearch,
    body: "Você passa semanas reconstruindo histórico de contratos antes de cada arbitragem ou consulta ju