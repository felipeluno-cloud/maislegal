import {
  Signature,
  Calendar,
  Sparkles,
  Plug,
  HelpCircle,
  ArrowRight
} from "lucide-react";
import { CtaDark } from "@/components/base/CtaDark";

const CATEGORIAS = [
  {
    icon: Signature,
    label: "Categoria 01",
    title: "Parceiros de assinatura",
    body: "Conexão com as principais plataformas brasileiras de assinatura eletrônica, para que o contrato seja assinado dentro do fluxo que você já usa. A assinatura acontece lá, mas a vida do contrato acontece aqui.",
    quote: "A assinatura é etapa, não produto inteiro.",
    status: "Disponível",
    color: "brand"
  },
  {
    icon: Calendar,
    label: "Categoria 02",
    title: "Calendário, CRM e comunicação",
    body: "Conexão com Slack, Google Calendar, HubSpot e Pipedrive, para que as obrigações do contrato sincronizem com o ritmo da operação e cheguem onde o time já está olhando.",
    quote: "Para que o contrato siga o pipeline.",
    status: "Em construção · Q3 2026",
    color: "peach"
  },
  {
    icon: Sparkles,
    label: "Categoria 03",
    title: "Add-ons planejados",
    body: "Consulta JUCESP, conexão com especialistas SOMA e digitalização de portfólio legado, pensados para quando a operação cresce e novos serviços passam a fazer sentido sobre o ambiente.",
    quote: "Não anunciado como disponível.",
    status: "Futuro",
    color: "soma"
  }
];

const OBJECOES = [
  {
    q: "Já tenho ferramenta de assinatura.",
    a: "A assinatura é apenas uma etapa do contrato, e a +legal_ gerencia tudo o que vem depois dela. A integração com as principais plataformas do mercado é nativa, então você não troca o que já funciona."
  },
  {
    q: "Tenho Drive ou pasta organizada.",
    a: "Drive guarda arquivo, mas a +legal_ guarda contexto, histórico e obrigações, e garante que quem está no contrato veja a mesma versão ao mesmo tempo."
  },
  {
    q: "Uso planilha para acompanhar.",
    a: "A planilha não acompanha o contrato sozinha, então a obrigação acaba esquecida porque depende de alguém lembrar de atualizar. Na +legal_, o sistema atualiza por você."
  }
];

const COLOR: Record<string, { border: string; bg: string; iconBg: string; iconText: string; pillBg: string; pillText: string }> = {
  brand: {
    border: "var(--brand)",
    bg: "var(--brand-tint)",
    iconBg: "var(--brand-tint)",
    iconText: "var(--brand)",
    pillBg: "white",
    pillText: "var(--brand)"
  },
  peach: {
    border: "var(--peach-dark)",
    bg: "var(--peach-bg)",
    iconBg: "var(--peach-bg)",
    iconText: "var(--peach-dark)",
    pillBg: "white",
    pillText: "var(--peach-dark)"
  },
  soma: {
    border: "var(--soma)",
    bg: "var(--soma-bg)",
    iconBg: "var(--soma-bg)",
    iconText: "var(--soma)",
    pillBg: "white",
    pillText: "var(--soma)"
  }
};

export default function IntegracoesPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Plug className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Integrações
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              A assinatura é etapa.
              <br />
              <span className="text-brand">Não produto inteiro.</span>
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              A +legal_ complementa as ferramentas que você já tem, sem
              tentar substituir a sua plataforma de assinatura, o Drive, ou
              o CRM. Ela cobre o espaço que existe entre todos esses
              sistemas, onde o contrato vive de verdade.
            </p>
          </div>
        </div>
      </section>

      {/* DIAGRAMA · onde a +legal_ se encaixa */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-4">Onde se encaixa</p>
            <h2 className="h-soma mb-4">
  