import Link from "next/link";
import { ArrowRight, BookOpen, Clock, User } from "lucide-react";
import { CtaDark } from "@/components/base/CtaDark";

const ARTIGOS = [
  {
    slug: "contrato-escrito-para-o-juiz",
    titulo: "O contrato foi escrito para o juiz. Ninguém o escreveu para o dia a dia.",
    autor: "Rafael Rossi",
    role: "Estratégia",
    initial: "R",
    summary:
      "Contratos mal monitorados criam três custos invisíveis: prazo (multas), reconstrução (semanas de jurídico) e relacionamento (litígio que poderia ter sido conversa).",
    categoria: "Gestão",
    color: "brand",
    leitura: "5 min"
  },
  {
    slug: "advogado-historico-organizado",
    titulo: "O que o seu advogado não consegue fazer sem histórico organizado.",
    autor: "Luis Fernando Hiar",
    role: "Contratos",
    initial: "L",
    summary:
      "Uma defesa sólida começa com informação completa. Sem histórico organizado, o advogado passa semanas reconstruindo fatos antes de começar a estratégia jurídica.",
    categoria: "Para Advogados",
    color: "peach",
    leitura: "6 min"
  },
  {
    slug: "combinar-pelo-whatsapp",
    titulo: "Combinar pelo WhatsApp é prático. É seguro?",
    autor: "Luis Fernando Hiar",
    role: "Contratos",
    initial: "L",
    summary:
      "Pequenas concessões informais se acumulam ao longo do tempo, e o WhatsApp é questionável como evidência quando o conflito chega. Um aditivo formal feito no ambiente colaborativo leva menos de cinco minutos.",
    categoria: "Educação",
    color: "peach",
    leitura: "4 min"
  },
  {
    slug: "conflitos-contratuais-custam-mais",
    titulo: "Por que conflitos contratuais custam mais do que parecem.",
    autor: "Rafael Rossi",
    role: "Estratégia",
    initial: "R",
    summary:
      "O custo visível é o valor em disputa, mais honorários. Os custos invisíveis: tempo de gestão, relacionamento queimado, reputação em due diligence, oportunidade de resolução precoce perdida.",
    categoria: "Disputas",
    color: "soma",
    leitura: "7 min"
  }
];

const COLOR: Record<string, { border: string; bg: string; text: string; pillBg: string }> = {
  brand: {
    border: "var(--brand)",
    bg: "var(--brand)",
    text: "var(--brand)",
    pillBg: "var(--brand-tint)"
  },
  peach: {
    border: "var(--peach-dark)",
    bg: "var(--peach-dark)",
    text: "var(--peach-dark)",
    pillBg: "var(--peach-bg)"
  },
  soma: {
    border: "var(--soma)",
    bg: "var(--soma)",
    text: "var(--soma)",
    pillBg: "var(--soma-bg)"
  }
};

export default function BlogPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <BookOpen className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Blog
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              Conteúdo sobre contratos vivos,
              <br />
              <span className="text-brand">gestão e resolução</span>.
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Os fundadores escrevem sobre o que veem na prática, com
              linguagem direta e sem promessas vagas. Cada texto começa em
              uma situação real, e termina em algo que dá para fazer
              diferente já amanhã.
            </p>
          </div>
        </div>
      </section>

  