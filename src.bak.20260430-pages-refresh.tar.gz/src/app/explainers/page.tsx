import { Lightbulb } from "lucide-react";
import { Explainer1 } from "@/components/explainers/Explainer1";
import { Explainer2 } from "@/components/explainers/Explainer2";
import { Explainer3 } from "@/components/explainers/Explainer3";
import { Explainer4 } from "@/components/explainers/Explainer4";

export default function ExplainersPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
          <div
            className="absolute h-[300px] w-[300px] rounded-full opacity-[0.05]"
            style={{ background: "var(--peach-dark)", bottom: "-80px", left: "-80px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Lightbulb className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Explainers visuais
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              Quatro analogias para explicar
              <br />
              <span className="text-brand">a +legal_ em segundos</span>.
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Quatro infográficos que usam analogias do mundo real para
              explicar a +legal_ a quem nunca ouviu falar dela. Cada um
              cobre um pilar diferente, com mapa, exemplos e a frase que
              fica na cabeça do interlocutor.
            </p>

            <div className="mt-8 flex flex-wrap gap-2">
              <a
                href="#explainer-01"
                className="rounded-full border border-stone-300 bg-white px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-gray-700 transition-colors hover:border-brand hover:text-brand"
              >
                01 · Telefone sem fio
              </a>
              <a
                href="#explainer-02"
                className="rounded-full border border-stone-300 bg-white px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-gray-700 transition-colors hover:border-peach-dark hover:text-peach-dark"
              >
                02 · Tripé fotográfico
              </a>
              <a
                href="#explainer-03"
                className="rounded-full border border-stone-300 bg-white px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-gray-700 transition-colors hover:border-soma hover:text-soma"
              >
                03 · Pronto-socorro acoplado
              </a>
              <a
                href="#explainer-04"
                className="rounded-full border border-stone-300 bg-white px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-gray-700 transition-colors hover:border-brand hover:text-brand"
              >
                04 · Construção de casa
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* EXPLAINERS */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="flex flex-col gap-10">
            <div id="explainer-01">
              <Explainer1 />
            </div>
            <div id="explainer-02">
              <Explainer2 />
            </div>
            <div id="explainer-03">
              <Explainer3 />
            </div>
            <div id="explainer-04">
              <Explainer4 />
            </div>
          </div>
        </div>
      </section>

      {/* CTA · uso futuro */}
      <section className="bg-white">
        <div className="container-soma section-soma">
          <div className="mx-auto max-w-[820px] rounded-2xl border-2 border-brand bg-brand-tint p-8 md:p-10">
            <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
              Próximos passos
            </p>
            <h2 className="mb-3 font-title text-2xl font-bold text-gray-900 md:text-3xl">
              Onde usar estes infográficos?
            </h2>
            <p className="mb-4 text-base leading-relaxed text-gray-700">
              Cada um pode virar post de blog, slide de pitch, carousel
              LinkedIn, asset de email marketing. Diga qual quer expandir e a
              gente prepara em formato pronto para uso.
            </p>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex gap-2">
                <span className="text-brand">•</span> 01 · Hero alternativo da
                Home (mostrar contraste hoje vs +legal_)
              </li>
              <li className="flex gap-2">
                <span className="text-brand">•</span> 02 · Slide de pitch
                investidor (3 pilares estruturais)
              </li>
              <li className="flex gap-2">
                <span className="text-brand">•</span> 03 · Asset principal de
                /resolucao-de-disputas
              </li>
              <li className="flex gap-2">
                <span className="text-brand">•</span> 04 · Carousel LinkedIn
                educativo
              </li>
       