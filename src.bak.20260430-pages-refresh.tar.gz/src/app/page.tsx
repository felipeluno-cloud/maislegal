import { Hero } from "@/components/home/Hero";
import { EmUmaFrase } from "@/components/home/EmUmaFrase";
import { RiscosSilenciosos } from "@/components/home/RiscosSilenciosos";
import { Pilar01Colaborativo } from "@/components/home/Pilar01Colaborativo";
import { Pilar02RascunhoResolucao } from "@/components/home/Pilar02RascunhoResolucao";
import { Pilar03CamaraAcoplada } from "@/components/home/Pilar03CamaraAcoplada";
import { MockupPlataforma } from "@/components/home/MockupPlataforma";
import { AnalogiasHome } from "@/components/home/AnalogiasHome";
import { OQueNaoE } from "@/components/home/OQueNaoE";
import { CtaDark } from "@/components/base/CtaDark";

export default function Home() {
  return (
    <>
      <Hero />
      <EmUmaFrase />
      <AnalogiasHome />
      <RiscosSilenciosos />
      <Pilar01Colaborativo />
      <Pilar02RascunhoResolucao />
      <Pilar03CamaraAcoplada />
      <MockupPlataforma />
      <OQueNaoE />
      <CtaDark
        eyebrow="Os primeiros workspaces moldam a +legal_"
        title="Operador sempre gratuito. Sem cartão. Sem c