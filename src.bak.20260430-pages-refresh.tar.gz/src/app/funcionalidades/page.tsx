import {
  Users,
  Bell,
  FilePlus,
  History,
  Cog,
  Scale,
  X,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/base/Button";
import { CtaDark } from "@/components/base/CtaDark";

const BLOCOS = [
  {
    icon: Users,
    num: "01",
    title: "Ambiente colaborativo",
    body: "Todos os envolvidos no contrato, em condições iguais. Não é o sistema do fornecedor nem do cliente. É de todos, sem favorecimento de quem comprou a ferramenta.",
    color: "brand"
  },
  {
    icon: Bell,
    num: "02",
    title: "Monitoramento e alertas",
    body: "Cada obrigação e cada ajuste do contrato é acompanhado dentro da plataforma, com alertas automáticos chegando 30, 60 ou 90 dias antes do prazo, para que nada vença sem aviso e nenhum compromisso passe batido.",
    color: "brand"
  },
  {
    icon: FilePlus,
    num: "03",
    title: "Aditivos formalizados",
    body: "Pequenas concessões deixam de ser apenas conversa. Cada ajuste vira aditivo registrado, com aprovação documentada de todos.",
    color: "peach"
  },
  {
    icon: History,
    num: "04",
    title: "Histórico que sobrevive",
    body: "Um log auditável guarda cada versão com a autoria, cada comentário ligado à cláusula que ele discute, e cada decisão registrada com data e responsável. Quando você precisar reconstruir o histórico, está tudo pronto.",
    color: "peach"
  },
  {
    icon: Cog,
    num: "05",
    title: "Tecnologia que extrai obrigações",
    body: "As cláusulas do contrato são convertidas em obrigações rastreáveis e eventos de calendário, e você decide o que fazer com cada alerta que chega. A tecnologia organiza o processo, as pessoas tomam as decisões.",
    color: "brand"
  },
  {
    icon: Scale,
    num: "06",
    title: "Resolução SOMA integrada",
    body: "Quando vira disputa, tudo já está pronto. A SOMA, nossa câmara de mediação e arbitragem, recebe o histórico do contrato com um clique.",
    color: "soma"
  }
];

const NEGACOES = [
  "Substituir advogados",
  "Assinatura digital (integramos)",
  "Inteligência artificial decidindo",
  "Drive ou repositório genérico",
  "Ser a câmara SOMA"
];

const COLOR: Record<string, { border: string; bg: string; iconBg: string; iconText: string; numBg: string; pillBg: string; pillText: string }> = {
  brand: {
    border: "var(--brand)",
    bg: "var(--brand-tint)",
    iconBg: "var(--brand-tint)",
    iconText: "var(--brand)",
    numBg: "var(--brand)",
    pillBg: "var(--brand-tint)",
    pillText: "var(--brand)"
  },
  peach: {
    border: "var(--peach-dark)",
    bg: "var(--peach-bg)",
    iconBg: "var(--peach-bg)",
    iconText: "var(--peach-dark)",
    numBg: "var(--peach-dark)",
    pillBg: "var(--peach-bg)",
    pillText: "var(--peach-dark)"
  },
  soma: {
    border: "var(--soma)",
    bg: "var(--soma-bg)",
    iconBg: "var(--soma-bg)",
    iconText: "var(--soma)",
    numBg: "var(--soma)",
    pillBg: "var(--soma-bg)",
    pillText: "var(--soma)"
  }
};

export default function FuncionalidadesPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
          <div
            className="absolute h-[300px] w-[300px] rounded-full opacity-[0.05]"
            style={{ background: "var(--peach-dark)", bottom: "-80px", left: "-80px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <span className="size-1.5 animate-pulse rounded-full bg-brand" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Funcionalidades
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              O ciclo completo do contrato.
              <br />
              <span className="text-brand">Numa só plataforma.</span>
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Criação e assinatura, todo o mercado tem. Renovação, idem. O
              que ninguém cobre é o dia a dia em execução, o espaço entre a
              assinatura e o vencimento, e é exatamente aí que a +legal_
              vive.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-stone-50">
        <div className=