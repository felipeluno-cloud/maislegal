import { ArrowRight, Check, Tag, Sparkles, HelpCircle } from "lucide-react";
import { Button } from "@/components/base/Button";
import { CtaDark } from "@/components/base/CtaDark";

const PLANOS = [
  {
    label: "Plano Gratuito",
    price: "R$ 0",
    period: "para sempre",
    desc: "1 operador por workspace, permanentemente. Visitantes (acesso somente leitura), sem limite, sem custo.",
    features: [
      "Repositório central",
      "Histórico de versões",
      "Alertas básicos",
      "Visitantes ilimitados",
      "Convite para a outra parte"
    ],
    audience: "Fundadores, profissionais autônomos, empresas testando.",
    cta: { label: "Entrar para o Early Access", href: "/early-access" },
    highlight: false,
    color: "stone"
  },
  {
    label: "Plano Time",
    price: "R$ 500",
    period: "por operador / mês",
    desc: "A partir do segundo operador, com todos os recursos da plataforma liberados para times que precisam operar em conjunto.",
    features: [
      "Tudo do plano Gratuito",
      "Painel de portfólio",
      "Integrações (Slack, Calendar, CRM)",
      "API",
      "Suporte prioritário"
    ],
    audience: "Equipes de operações, times jurídicos internos, empresas com portfólio.",
    cta: { label: "Entrar para o Early Access", href: "/early-access" },
    highlight: true,
    color: "brand"
  },
  {
    label: "Escritórios",
    price: "R$ 250",
    period: "por operador / mês",
    desc: "Modelo diferenciado que considera o volume de relacionamentos ativos e as credenciais externas do escritório, com a estrutura exata ainda em definição.",
    features: [
      "Tudo do plano Time",
      "Acesso como advogado externo",
      "Visibilidade do portfólio do cliente",
      "Exportação para a câmara",
      "Preço por relacionamentos ativos"
    ],
    audience: "Bancas consultivas e contenciosas que adotam para o portfólio de clientes.",
    cta: { label: "Falar com a equipe", href: "mailto:contato@maislegal.tech" },
    highlight: false,
    color: "soma"
  }
];

const FAQ = [
  {
    q: "O que conta como 'operador'?",
    a: "Qualquer usuário que edita, assina ou aprova contratos. Visitantes (acesso somente leitura) não contam como operadores."
  },
  {
    q: "Como funciona o desconto SOMA do Premium?",
    a: "20% de desconto nas taxas de administração da câmara SOMA. Não se aplica aos honorários de árbitros ou mediadores."
  },
  {
    q: "O que muda no Premium?",
    a: "Add-on sobre o plano base. Inclui desconto no preço por operador, 20% de desconto nas taxas SOMA e biblioteca expandida de templates."
  },
  {
    q: "Tem trial limitado?",
    a: "O primeiro operador é gratuito permanente, não é trial. Você usa quanto tempo quiser, com um operador, sem custo."
  },
  {
    q: "Tem contrato anual?",
    a: "Não. Pagamento mensal, sem fidelidade. Você cancela quando quiser."
  },
  {
    q: "Como cancela?",
    a: "Pelo próprio painel, em poucos cliques. Os contratos ficam acessíveis para exportação em formato aberto por 90 dias depois do cancelamento."
  }
];

export default function PrecosPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.05]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Tag className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Preços
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              Operador sempre gratuito.
              <br />
              <span className="text-brand">Os outros, R$ 500.</span>
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Sem demo obrigatória, sem preço escondido. O que está escrito
              aqui é exatamente o que você paga, e o primeiro operador é
              gratuito de forma permanente, em qualquer plano.
            </p>
          </div>
        </div>
      </section>

      {/* 3 PLANOS */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {PLANOS.map(p => {
              const isBrand = p.color === "brand";
              const isSoma = p.color === "soma";
              const accentColor = isBrand ? "var(--brand)" : isSoma ? "var(--soma)" : "var(--grey-3)";
              const accentBg = isBrand ? "var(--brand-tint)" : isSoma ? "var(--soma-bg)" : "#F4F4F2";

              return (
                <div
                  key={p.label}
                  className={`flex flex-col overflow-hidden rounded-2xl border-2 bg-white transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                    p.highlight ? "shadow-lg ring-4 ring-brand/10" : ""
                  }`}
                  style={{ borderColor: p.highlight ? "var(--brand)" : "var(--grey-2)" }}
                >
                  {p.highlight && (
                    <div
                      className="px-7 py-2 text-center font-mono text-[10px] font-bold uppercase tracking-widest text-white"
                      style={{ background: "var(--brand)" }}
                    >
                      Mais comum
                    </div>
                  )}

                  <div className="flex flex-1 flex-col p-7">
                    <p
                      className="mb-2 font-mono text-xs uppercase tracking-widest"
                      style={{ color: accentColor }}
                    >
                      {p.label}
                    </p>

                    <div className="mb-5 flex items-baseline gap-2">
                      <p
                        className="font-title text-5xl font-extrabold tracking-tighter"
                        style={{ color: accentColor }}
                      >
                        {p.price}
                      </p>
                    </div>
                    <p className="mb-6 text-sm text-stone-500">{p.period}</p>

                    <p className="mb-6 text-sm leading-relaxed text-gray-700">
                      {p.desc}
                    </p>

                    <ul className="mb-6 space-y-2.5 border-y border-stone-200 py-5">
                      {p.features.map(f => (
                        <li
                          key={f}
                          className="flex items-start gap-2.5 text-sm text-gray-700"
                        >
                          <Check
                            className="mt-0.5 size-4 flex-shrink-0"
                            style={{ color: accentColor }}
                            strokeWidth={2.5}
                          />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>

                    <p className="mb-5 text-xs italic text-gray-600">
                      {p.audience}
                    </p>

                    <Button
                      href={p.cta.href}
                      variant={p.highlight ? "primary" : "secondary"}
                      size="md"
                      className={`w-full ${
                        isSoma && !p.highlight
                          ? "!border-soma/40 !text-soma hover:!bg-soma-bg"
                          : ""
          