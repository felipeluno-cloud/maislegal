import {
  ArrowRight,
  GitBranch,
  UserPlus,
  Shield,
  ShieldCheck,
  Calendar,
  MessageSquare
} from "lucide-react";
import { Button } from "@/components/base/Button";

// 3 mudanças concretas no dia da Sócia de PME
const MUDANCAS = [
  {
    icon: GitBranch,
    title: "Mesma versão pra você e pro cliente grande",
    body: "O cliente corporativo abre o mesmo contrato que você está editando. Comentários ficam onde a discussão acontece, e versão A contra versão B deixa de existir quando alguém precisa lembrar o que foi combinado.",
    visual: "versao"
  },
  {
    icon: UserPlus,
    title: "Advogado externo trabalha com você, não em paralelo",
    body: "Você convida o advogado externo direto pro contrato. Ele revisa dentro do ambiente, sem você precisar exportar PDF, anexar em e-mail e esperar resposta. O acesso de visitante é gratuito permanente.",
    visual: "advogado"
  },
  {
    icon: Shield,
    title: "Quando trava, resolve privado",
    body: "Se o contrato vira disputa, a câmara SOMA está acoplada. Mediação confidencial, sem expor a relação publicamente. Resolução privada, do mesmo ambiente, sem fila judicial e sem queimar o cliente.",
    visual: "soma"
  }
];

// Day 0 → 30 → 90 do onboarding pra PME
const RAMP = [
  {
    when: "Day 0",
    title: "Os 5 contratos críticos importados",
    body: "A equipe da +legal_ importa com você os contratos com clientes corporativos ativos, configura os campos, e cadastra seu advogado externo como visitante gratuito."
  },
  {
    when: "Day 30",
    title: "Próximo contrato nasce dentro",
    body: "O próximo contrato com cliente corporativo é negociado direto na +legal_. O cliente entra como editor, seu advogado revisa por dentro, e tudo fica registrado desde o rascunho."
  },
  {
    when: "Day 90",
    title: "Drive virou backup",
    body: "Os contratos vivos vivem na +legal_. O Drive ficou só como backup. Quando alguém pergunta o que foi combinado, a resposta está a um clique, não num e-mail de 2024."
  }
];

// 3 motivos específicos de Early Access para PMEs
const PORQUE_AGORA = [
  {
    icon: ShieldCheck,
    title: "Onboarding com a equipe",
    body: "A equipe da +legal_ importa os primeiros contratos com você, ajusta os campos do seu negócio, e cadastra seu advogado externo como visitante gratuito permanente."
  },
  {
    icon: Calendar,
    title: "Operador gratuito permanente",
    body: "Você como operador continua gratuito mesmo depois do produto entrar em fase comercial. O preço de lançamento dos próximos seats fica garantido para os primeiros workspaces."
  },
  {
    icon: MessageSquare,
    title: "Voz direta nos fundadores",
    body: "Os primeiros workspaces moldam o produto. Seu feedback vai direto para os fundadores e orienta o que entra em produção nos próximos meses."
  }
];

export default function ParaPmesPage() {
  return (
    <>
      {/* HERO · fala diretamente com a Sócia de PME */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[520px] w-[520px] rounded-full opacity-[0.06]"
            style={{ background: "var(--peach-dark)", top: "-160px", right: "-160px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <div
                className="mb-6 inline-flex items-center gap-2 rounded-full border px-3 py-1.5"
                style={{ background: "var(--peach-bg)", borderColor: "rgba(212,148,90,0.4)" }}
              >
                <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-peach-dark">
                  Para PMEs sem time jurídico
                </span>
              </div>

              <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-[52px] leading-[1.06]">
                Você fechou um contrato com uma empresa 50× maior que a sua. E agora?
              </h1>

              <p className="mb-8 text-lg leading-relaxed text-gray-600 md:text-xl">
                A +legal_ é o ambiente onde você, o cliente corporativo, e seu
                advogado externo trabalham na mesma versão do contrato. Sem
                exportar PDF, sem perder o histórico no e-mail, sem pular para
                o jurídico cada vez que alguém precisa entender o que mudou.
                Quando o cliente assume sua importância, você precisa estar do
                outro lado da mesa em pé de igualdade.
              </p>

              <div className="flex flex-wrap gap-3">
                <Button
                  href="/early-access"
                  variant="primary"
                  size="lg"
                  className="!bg-peach-dark !border-peach-dark hover:!bg-peach-dark/90"
                >
                  Entrar para o Early Access <ArrowRight className="size-4" />
                </Button>
                <Button
                  href="mailto:contato@maislegal.tech?subject=Conversa%20sobre%20PME"
                  variant="secondary"
                  size="lg"
                  className="!border-stone-300"
                >
                  Conversar com a equipe
                </Button>
              </div>

              <p className="mt-5 font-mono text-[11px] uppercase tracking-widest text-gray-500">
                Operador grátis · sem cartão · advogado externo de cortesia
              </p>
            </div>

            <div className="hidden lg:block">
              <MockupContratoColaborativo />
            </div>
          </div>
        </div>
      </section>

      {/* O QUE MUDA NA PRÁTICA · 3 mudanças com mini-visuais */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-3 text-peach-dark">O que muda no dia a dia</p>
            <h2 className="h-soma mb-4">
              Três coisas que param de pesar, na hora que entra.
            </h2>
            <p className="text-lg leading-relaxed text-gray-600">
              Não é uma promessa de transformação genérica. É o que aparece no
              navegador na primeira semana e fica visível em todo contrato dali
              pra frente.
            </p>
          </div>

          <div className="space-y-12">
            {MUDANCAS.map((m, i) => {
              const Icon = m.icon;
              const reverse = i % 2 === 1;
              return (
                <div
                  key={m.title}
                  className="grid grid-cols-1 items-center gap-8 lg:grid-cols-2"
                >
                  <div className={reverse ? "lg:order-2" : ""}>
                    <div
                      className="mb-5 flex size-11 items-center justify-center rounded-xl"
                      style={{ background: "var(--peach-bg)" }}
                    >
                      <Icon className="size-5 text-peach-dark" strokeWidth={1.6} />
                    </div>
                    <h3 className="mb-3 font-title text-2xl font-bold leading-snug text-gray-900 md:text-3xl">
                      {m.title}
                    </h3>
                    <p className="text-[15px] leading-relaxed text-gray-700 md:text-base">
                      {m.body}
                    </p>
                  </div>

                  <div className={reverse ? "lg:order-1" : ""}>
                    <div
                      className="rounded-2xl border p-5 shadow-sm"
                      style={{
                        background: "white",
                        borderColor: "rgba(212,148,90,0.25)"
                      }}
                    >
                      {m.visual === "versao" && <VisualVersao />}
                      {m.visual === "advogado" && <VisualAdvogado />}
                      {m.visual === "soma" && <VisualSoma />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* COMO COMEÇA · Day 0 / 30 / 90 */}
      <section className="bg-white">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-3 text-peach-dark">Como começa</p>
            <h2 className="h-soma mb-4">
              Do primeiro contrato importado até o Drive virar backup.
            </h2>
            <p className="text-lg leading-relaxed text-gray-600">
              Você não precisa virar especialista em mais uma ferramenta. A
              equipe da +legal_ acompanha os primeiros passos, e em 90 dias o
              ambiente já é onde a conversa de contrato acontece.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
            {RAMP.map((step, i) => (
              <div
                key={step.when}
                className="rounded-2xl border border-stone-200 bg-white p-7"
              >
                <div className="mb-5 flex items-center gap-3">
                  <div
                    className="flex size-9 items-center justify-center rounded-full font-mono text-[10px] 