import {
  Gift,
  Zap,
  MessageSquare,
  ShieldCheck,
  Compass,
  Lock,
  Sparkles,
  HelpCircle
} from "lucide-react";
import { Button } from "@/components/base/Button";

const BENEFITS = [
  {
    icon: Gift,
    title: "Operador gratuito para sempre",
    body: "Quem entra no Early Access garante que o primeiro operador do workspace seja gratuito de forma permanente, sem prazo de expiração e sem mudança de regra no futuro.",
    color: "brand"
  },
  {
    icon: Zap,
    title: "Acesso prioritário a novidades",
    body: "A entrega das funcionalidades é gradual, e elas chegam primeiro para quem está no Early Access, antes do lançamento público para o resto do mercado.",
    color: "brand"
  },
  {
    icon: MessageSquare,
    title: "Acesso direto aos fundadores",
    body: "Feedback ouvido por quem decide. Conversas regulares com Rafael, Paula, Luis e Raul orientam a evolução do produto.",
    color: "peach"
  },
  {
    icon: ShieldCheck,
    title: "20% de desconto na câmara SOMA",
    body: "Quando uma disputa precisar ser resolvida, as taxas da câmara SOMA têm 20% de desconto para os usuários do plano Premium.",
    color: "soma"
  },
  {
    icon: Compass,
    title: "Onboarding com a equipe",
    body: "Importação dos primeiros contratos com apoio direto da equipe. Configuração inicial em horas, do zero ao primeiro alerta funcional.",
    color: "peach"
  },
  {
    icon: Lock,
    title: "Preço de lançamento garantido",
    body: "Os primeiros workspaces preservam o preço de lançamento. Sem reajustes futuros, mesmo após a +legal_ consolidar tração de mercado.",
    color: "brand"
  }
];

const FAQ = [
  {
    q: "É realmente gratuito?",
    a: "Sim, o primeiro operador de cada workspace é gratuito de forma permanente, sem cartão de crédito e sem trial limitado. A partir do segundo operador, o valor é R$ 500 por mês."
  },
  {
    q: "Quanto tempo dura o Early Access?",
    a: "Não há prazo fixo. O Early Access fecha quando a gente atingir o número de workspaces que conseguimos acompanhar com qualidade, e os benefícios permanecem para quem já entrou."
  },
  {
    q: "Posso convidar a outra parte do contrato?",
    a: "Sim. Visitantes (acesso somente leitura) não geram cobrança. A outra parte do contrato acessa de graça como visitante."
  },
  {
    q: "Como funciona o cancelamento?",
    a: "Sem multa, sem fidelidade. Você cancela quando quiser. Os contratos continuam exportáveis em formato aberto."
  }
];

const COLOR: Record<string, { border: string; bg: string; iconBg: string; iconColor: string }> = {
  brand: {
    border: "var(--brand)",
    bg: "var(--brand-tint)",
    iconBg: "var(--brand)",
    iconColor: "white"
  },
  peach: {
    border: "var(--peach-dark)",
    bg: "var(--peach-bg)",
    iconBg: "var(--peach-dark)",
    iconColor: "white"
  },
  soma: {
    border: "var(--soma)",
    bg: "var(--soma-bg)",
    iconBg: "var(--soma)",
    iconColor: "white"
  }
};

export default function EarlyAccessPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[700px] w-[700px] rounded-full opacity-[0.05]"
            style={{ background: "var(--brand)", top: "-200px", right: "-150px" }}
          />
          <div
            className="absolute h-[300px] w-[300px] rounded-full opacity-[0.06]"
            style={{ background: "var(--peach-dark)", bottom: "-80px", left: "-60px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[860px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <span className="size-1.5 animate-pulse rounded-full bg-brand" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Early Access
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              Os primeiros workspaces
              <br />
              <span className="text-brand">moldam a +legal_</span>.
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Não é fila de espera passiva. É curadoria ativa: quem entra
              agora tem acesso prioritário, voz no desenvolvimento do produto
              e operador gratuito permanente.
            </p>
          </div>
        </div>
      </section>

      {/* BENEFÍCIOS · 6 cards */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Sparkles className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Benefícios
              </span>
            </div>
            <h2 className="h-soma mb-4">
              Seis razões para entrar agora, e não depois.
            </h2>
            <p className="text-lg leading-relaxed text-gray-600">
              Quem está no Early Access ganha mais do que acesso antecipado.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {BENEFITS.map((b, i) => {
              const c = COLOR[b.color];
              const Icon = b.icon;
              return (
                <div
                  key={b.title}
                  className="flex flex-col rounded-2xl border border-stone-200 border-l-4 bg-white p-7 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  style={{ borderLeftColor: c.border }}
                >
                  <div className="mb-5 flex items-center justify-between">
                    <div
                      className="flex size-12 items-center justify-center rounded-xl"
                      style={{ background: c.iconBg }}
                    >
                      <Icon
                        className="size-6"
                        style={{ color: c.iconColor }}
                        strokeWidth={1.6}
                      />
                    </div>
                    <span
                      className="rounded-full px-2.5 py-0.5 font-mono text-[10px] font-bold tracking-widest"
                      style={{ background: c.bg, color: c.border }}
                    >
                      0{i + 1}
                    </span>
                  </div>
                  <h3 className="mb-3 font-title text-lg font-bold leading-snug text-gray-900">
                    {b.title}
                  </h3>
                  <p className="text-sm leading-relaxed text-gray-700">
                    {b.body}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CADASTRO · formulário */}
      <section className="bg-white">
        <div className="container-soma section-soma">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.2fr]">
            <div>
              <p className="eyebrow mb-4">Cadastro</p>
              <h2 className="h-soma mb-6">
                Diga quem você é. A gente responde em 3 dias úteis.
              </h2>
              <p className="mb-8 text-lg leading-relaxed text-gray-600">
                A equipe da +legal_ entra em contato para alinhar
                expectativas, entender o seu portfólio de contratos e
                acompanhar a importação inicial.
              </p>

              <div className="space-y-3">
                <div className="flex items-start gap-3 rounded-xl bg-brand-tint p-4">
                  <div className="flex size-9 flex-shrink-0 items-center justify-center rounded-lg bg-brand text-white">
                    <Gift className="size-4" strokeWidth={2} />
                  </div>
                  <p className="pt-1.5 text-sm font-medium text-gray-900">
                    Sem cartão. Sem cobrança. Sem compromisso.
                  </p>
                </div>
                <div className="flex items-start gap-3 rounded-xl bg-brand-tint p-4">
                  <div className="flex size-9 flex-shrink-0 items-center justify-center rounded-lg bg-brand text-white">
                    <MessageSquare className="size-4" strokeWidth={2} />
                  </div>
                  <p className="pt-1.5 text-sm font-medium text-gray-900">
                    Conversa direta com a equipe que está construindo.
                  </p>
                </div>
              </div>
            </div>

            <form className="flex flex-col gap-5 rounded-2xl