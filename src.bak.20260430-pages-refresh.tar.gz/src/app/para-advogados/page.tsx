import {
  ArrowRight,
  FileSearch,
  Layers,
  Send,
  ShieldCheck,
  Calendar,
  MessageSquare
} from "lucide-react";
import { Button } from "@/components/base/Button";

// 3 mudanças concretas no dia da sócia/sócio de escritório
const MUDANCAS = [
  {
    icon: FileSearch,
    title: "Histórico íntegro, não reconstruído",
    body: "Você abre o caso e o histórico já está pronto. Cada versão do contrato, cada comentário trocado, cada aditivo, registrado e auditável. Em vez de gastar 3 semanas reconstruindo o que aconteceu, você lê o que aconteceu.",
    visual: "historico"
  },
  {
    icon: Layers,
    title: "Vista única dos clientes ativos",
    body: "Em vez de pular entre sistemas diferentes para cada cliente, todos os contratos dos clientes que você atende ficam numa só tela, com status, prazos e obrigações visíveis. O cliente entra como visitante, gratuito.",
    visual: "vista"
  },
  {
    icon: Send,
    title: "Dossiê pronto pra câmara",
    body: "Quando o caso vira arbitragem ou mediação, o dossiê do contrato exporta direto pra SOMA em formato aceito pela câmara. As 11 versões em drives diferentes que você gastaria semanas montando já estão consolidadas.",
    visual: "dossie"
  }
];

// Day 0 → 30 → 90 do onboarding pra escritório
const RAMP = [
  {
    when: "Day 0",
    title: "Onboarding com curadoria",
    body: "A equipe da +legal_ configura o workspace do escritório, importa os contratos dos primeiros clientes, e cadastra os advogados externos como visitantes gratuitos."
  },
  {
    when: "Day 30",
    title: "Próximo cliente já entra dentro",
    body: "O próximo cliente que você atende abre conta como editor convidado. Os contratos passam a viver no ambiente desde o rascunho, com histórico íntegro registrado em tempo real."
  },
  {
    when: "Day 90",
    title: "Caso novo, histórico íntegro",
    body: "Quando o caso chega, o histórico está pronto. Você abre o cliente, vê os contratos ativos, identifica a cláusula em discussão, e passa direto para a estratégia, em vez de para a investigação."
  }
];

// 3 motivos específicos de Early Access para escritórios
const PORQUE_AGORA = [
  {
    icon: ShieldCheck,
    title: "Preço diferenciado por relacionamentos ativos",
    body: "R$ 250 por operador, com modelo que considera o número de relacionamentos ativos e credenciais externas como especialização em arbitragem e registros na OAB."
  },
  {
    icon: Calendar,
    title: "Cliente entra gratuito",
    body: "O cliente que você atende entra como editor convidado sem custo adicional, e cada workspace que você cria vira ponto de adoção para o próximo cliente do seu cliente."
  },
  {
    icon: MessageSquare,
    title: "Voz direta nos fundadores",
    body: "Os primeiros escritórios moldam o produto. Funcionalidades de contencioso e consultivo vêm pela frente, e seu feedback orienta o que entra em produção."
  }
];

export default function ParaAdvogadosPage() {
  return (
    <>
      {/* HERO · fala diretamente com a sócia/sócio de escritório */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[520px] w-[520px] rounded-full opacity-[0.06]"
            style={{ background: "var(--soma)", top: "-160px", right: "-160px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <div
                className="mb-6 inline-flex items-center gap-2 rounded-full border px-3 py-1.5"
                style={{ background: "var(--soma-bg)", borderColor: "rgba(184,97,78,0.4)" }}
              >
                <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-soma">
                  Para escritórios consultivos e contenciosos
                </span>
              </div>

              <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-[52px] leading-[1.06]">
                Você passa 3 semanas reconstruindo histórico antes de cada caso. E se ele já estivesse pronto?
              </h1>

              <p className="mb-8 text-lg leading-relaxed text-gray-600 md:text-xl">
                A +legal_ é o ambiente onde os contratos dos seus clientes vivem
                desde o rascunho, com cada versão, comentário e aditivo registrado
                e auditável. Quando o caso chega, você abre o cliente e o histórico
                está íntegro. Em vez de três semanas de investigação preliminar,
                você passa direto para a estratégia.
              </p>

              <div className="flex flex-wrap gap-3">
                <Button
                  href="mailto:contato@maislegal.tech?subject=Conversa%20com%20escrit%C3%B3rio"
                  variant="primary"
                  size="lg"
                  className="!bg-soma !border-soma hover:!bg-soma/90"
                >
                  Falar com a equipe <ArrowRight className="size-4" />
                </Button>
                <Button
                  href="/early-access"
                  variant="secondary"
                  size="lg"
                  className="!border-stone-300"
                >
                  Early Access individual
                </Button>
              </div>

              <p className="mt-5 font-mono text-[11px] uppercase tracking-widest text-gray-500">
                Preço diferenciado · cliente gratuito · onboarding com curadoria
              </p>
            </div>

            <div className="hidden lg:block">
              <MockupVistaEscritorio />
            </div>
          </div>
        </div>
      </section>

      {/* O QUE MUDA NA PRÁTICA · 3 mudanças com mini-visuais */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-3 text-soma">O que muda no escritório</p>
            <h2 className="h-soma mb-4">
              Três coisas que param de pesar, na hora que entra.
            </h2>
            <p className="text-lg leading-relaxed text-gray-600">
              Não é uma promessa de transformação genérica. É o que aparece no
              navegador na primeira semana e fica visível em todo cliente dali
              pra frente.
            </p>
          </div>

          <div className="space-y-12">
            {MUDANCAS.map((m, i) => {
              const Icon = m.icon;
              const reverse = i % 2 === 1;
              return (
                <div
                  key={m.title}
                  className="grid grid-cols-1 items-center gap-8 lg:grid-cols-2"
                >
                  <div className={reverse ? "lg:order-2" : ""}>
                    <div
                      className="mb-5 flex size-11 items-center justify-center rounded-xl"
                      style={{ background: "var(--soma-bg)" }}
                    >
                      <Icon className="size-5 text-soma" strokeWidth={1.6} />
                    </div>
                    <h3 className="mb-3 font-title text-2xl font-bold leading-snug text-gray-900 md:text-3xl">
                      {m.title}
                    </h3>
                    <p className="text-[15px] leading-relaxed text-gray-700 md:text-base">
                      {m.body}
                    </p>
                  </div>

                  <div className={reverse ? "lg:order-1" : ""}>
                    <div
                      className="rounded-2xl border p-5 shadow-sm"
                      style={{
                        background: "white",
                        borderColor: "rgba(184,97,78,0.25)"
                      }}
                    >
                      {m.visual === "historico" && <VisualHistoricoIntegro />}
                      {m.visual === "vista" && <VisualVistaCliente />}
                      {m.visual === "dossie" && <VisualDossieSoma />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* COMO COMEÇA · Day 0 / 30 / 90 */}
      <section className="bg-white">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-3 text-soma">Como começa</p>
            <h2 className="h-soma mb-4">
              Do primeiro cliente importado até o caso novo chegar com histórico íntegro.
            </h2>
            <p className="text-lg leading-relaxed text-gray-600">
              O escritório não vira beta-tester. A equipe da +legal_ acompanha
              o setup, importa os contratos dos primeiros clientes, e em 90 dias
              o ambiente já é onde a documentação acontece.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
            {RAMP.map((step, i) => (
              <div
                key={step.when}
                className="rounded-2xl border border-stone-200 bg-white p-7"
              >
                <div className="mb-5 flex items-center gap-3">
                  <div
                    className="flex size-9 items-center justify-center rounded-full font-mono text-[10px] font-bold text-white"
                    style={{ background: "var(--soma)" }}
                  >
                    0{i + 1}
                  </div>
                  <p className="font-mono text-[11px] font-bold uppercase tracking-widest text-soma">
                    {step.when}
                  </p>
                </div>
                <h3 className="mb-3 font-title text-lg font-bold text-gray-900">
                  {step.title}
                </h3>
   