import { Heart, Target, Compass, Users, Scale } from "lucide-react";
import { CtaDark } from "@/components/base/CtaDark";

const FUNDADORES = [
  {
    nome: "Rafael Rossi",
    role: "Estratégia",
    initial: "R",
    color: "brand",
    cred:
      "MSc Economia (University of York), Bc. Direito (USP), Bc. Administração (FGV-EAESP). 5 anos em pricing e estratégia em tech startups (Oda, Glovo)."
  },
  {
    nome: "Paula Abi-Chahine",
    role: "Câmara",
    initial: "P",
    color: "soma",
    cred:
      "PhD e MSc Direito Processual Civil (USP). Professora no Insper. 18 anos em arbitragem e contencioso cível em Lobo & de Rizzo, ASBZ e Mattos Filho."
  },
  {
    nome: "Luis Fernando Hiar",
    role: "Contratos",
    initial: "L",
    color: "peach",
    cred:
      "MSc Direito Contratual (Insper), Bc. Direito (USP). 13 anos em arbitragem e contencioso cível, em Lobo & de Rizzo e Lefosse."
  },
  {
    nome: "Raul Mariotti",
    role: "Tecnologia",
    initial: "R",
    color: "brand",
    cred:
      "Bc. Análise de Sistemas (Unicamp), Fullbright Scholar (Daytona State College). 19 anos em tecnologia da informação e engenharia de software."
  }
];

const PRINCIPIOS = [
  {
    icon: Target,
    title: "Ambiente justo.",
    body: "Nenhum dos lados tem vantagem de casa. O ambiente pertence a todos os envolvidos no contrato, não é ferramenta de uma parte só."
  },
  {
    icon: Compass,
    title: "Clareza radical.",
    body: "O que foi combinado fica combinado, sem versões paralelas e sem surpresas no final, porque o registro é único e pertence a todos os envolvidos no contrato."
  },
  {
    icon: Heart,
    title: "Coração jurídico. Alma comercial.",
    body: "A +legal_ respeita a precisão da lei e a velocidade do negócio, sem precisar escolher entre os dois. No fim das contas, contratos são sobre relações comerciais, não sobre papel."
  }
];

const COLOR_PERSONA: Record<string, { bg: string; text: string; border: string }> = {
  brand: { bg: "var(--brand)", text: "white", border: "var(--brand)" },
  peach: { bg: "var(--peach-dark)", text: "white", border: "var(--peach-dark)" },
  soma: { bg: "var(--soma)", text: "white", border: "var(--soma)" }
};

export default function SobrePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
          <div
            className="absolute h-[300px] w-[300px] rounded-full opacity-[0.05]"
            style={{ background: "var(--peach-dark)", bottom: "-80px", left: "-80px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Heart className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Sobre
              </span>
            </div>

            <h1 className="mb-4 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-[64px] leading-[1.05]">
              Coração jurídico.
              <br />
              <span className="text-peach-dark">Alma comercial.</span>
            </h1>

            <p className="mb-8 font-mono text-xs uppercase tracking-widest text-stone-500">
              — Rafael Rossi
            </p>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl max-w-[760px]">
              A +legal_ existe porque contratos terminam fragmentados em
              sistemas de cada parte. Voltam só quando já é tarde, e a relação
              comercial paga o preço dessa desorganização.
            </p>
          </div>
        </div>
      </section>

      {/* POR QUE EXISTIMOS · manifesto */}
      <section className="bg-white">
        <div className="container-soma section-soma">
          <div className="mx-auto max-w-[820px]">
            <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <span className="size-1.5 rounded-full bg-brand" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Por que existimos
              </span>
            </div>

            <h2 className="h-soma mb-8">
              A camada que faltava entre o jurídico e o comercial.
            </h2>

            <div className="space-y-6 text-lg leading-relaxed text-gray-700">
              <p>
                A +legal_ nasceu da observação de algo que se repete em
                empresas B2B do Brasil inteiro: contratos são fechados com
                muito cuidado, com horas de negociação e revisão, e depois
                desaparecem em pastas, drives e e-mails. Quando voltam à
                tona, geralmente já é tarde.
              </p>
              <p>
                Os quatro fundadores chegaram a esse problema por caminhos
                diferentes. Paula e Luis viam o lado pós-conflito, com
                escritórios passando semanas reconstruindo histórico antes
                de cada arbitragem. Raul vinha do lado da tecnologia, onde
                ferramentas existem mas não se conversam. Rafael vinha de
                operações comerciais em startups, onde o contrato é o que
                organiza o relacionamento entre cliente e fornecedor.
              </p>
              <p>
                A conclusão veio rápido: o problema não é jurídico isolado,
                nem tecnológico. É de relacionamento comercial. Faltava uma
                camada entre as duas pontas, que respeitasse a precisão do
                jurídico mas operasse na velocidade do negócio. Coração
                jurídico, alma comercial.
              </p>
              <p>
                A +legal_ é essa camada. Um ambiente colaborativo entre
                quem participa do contrato, com cuidado contínuo durante o
                ciclo inteiro, e com a câmara SOMA acoplada para quando uma
                disputa precisar ser resolvida. Tudo no mesmo lugar, sem
                exigir que ninguém troque a stack que já usa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* MI