import { Shield, AlertCircle, Mail } from "lucide-react";
import { Button } from "@/components/base/Button";

const SECOES = [
  "Dados pessoais coletados",
  "Finalidade do tratamento",
  "Compartilhamento com terceiros",
  "Direitos do titular dos dados",
  "Tempo de retenção",
  "Medidas de segurança",
  "Cookies e tecnologias de rastreamento",
  "Encarregado de dados (DPO)",
  "Atualizações desta política"
];

export default function PrivacidadePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[500px] w-[500px] rounded-full opacity-[0.04]"
            style={{ background: "var(--brand)", top: "-150px", right: "-150px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[820px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <Shield className="size-4 text-brand" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Política de Privacidade
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-6xl">
              Como tratamos
              <br />
              <span className="text-brand">os seus dados</span>.
            </h1>

            <p className="text-lg leading-relaxed text-gray-600 md:text-xl">
              Texto integral da Política de Privacidade da +legal_, em
              conformidade com a LGPD. Documento em elabora�