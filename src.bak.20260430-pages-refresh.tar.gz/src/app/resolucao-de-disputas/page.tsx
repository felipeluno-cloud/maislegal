import {
  ArrowRight,
  ShieldCheck,
  MousePointerClick,
  Coins,
  Lock,
  Star,
  Monitor,
  Users,
  Clock,
  ExternalLink,
  Scale,
  Building2
} from "lucide-react";
import { Button } from "@/components/base/Button";
import { CtaDark } from "@/components/base/CtaDark";

const PRACTICE = [
  {
    icon: ShieldCheck,
    title: "Histórico disponível",
    body: "Árbitro ou mediador acessa o histórico completo do contrato, sem reconstrução manual."
  },
  {
    icon: MousePointerClick,
    title: "Abertura com 1 clique",
    body: "Qualquer parte abre procedimento direto do contrato na plataforma."
  },
  {
    icon: Coins,
    title: "Crédito de mediação",
    body: "Se a mediação não resolve, os honorários viram desconto na arbitragem."
  },
  {
    icon: Lock,
    title: "Sigilo por padrão",
    body: "Nada da resolução é público, nem o fato de ter ocorrido."
  },
  {
    icon: Star,
    title: "Plano Premium",
    body: "20% de desconto nas taxas de administração da câmara SOMA."
  }
];

const FLUXO = [
  { num: "01", label: "Contrato em curso", body: "Acompanhamento normal pela +legal_, com histórico, alertas e obrigações sob monitoramento." },
  { num: "02", label: "Divergência", body: "Surge um desacordo entre as partes sobre cumprimento ou interpretação de uma cláusula." },
  { num: "03", label: "Câmara SOMA acoplada", body: "O procedimento é aberto com um clique e o histórico do contrato já está disponível para a câmara." },
  { num: "04", label: "Resolução em meses", body: "A mediação vem primeiro, com incentivo financeiro, e a arbitragem entra só se a mediação não resolver." }
];

const CARACTERISTICAS = [
  { icon: Monitor, title: "100% digital", body: "Sem deslocamento, sem papel, e sem necessidade de contratar advogados locais para representação." },
  { icon: Users, title: "Especialistas por área", body: "Árbitros e mediadores são selecionados conforme a matéria do conflito, para garantir competência específica em cada caso." },
  { icon: Clock, title: "Procedimento simplificado", body: "Para causas menores, com até 6 meses de duração e custos publicados na tabela pública da câmara." },
  { icon: Scale, title: "Procedimento padrão", body: "Para disputas mais complexas, com até 1 ano de duração e mais fases de produção de prova." }
];

export default function ResolucaoPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-stone-200 bg-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute h-[700px] w-[700px] rounded-full opacity-[0.07]"
            style={{ background: "var(--soma)", top: "-200px", right: "-200px" }}
          />
          <div
            className="absolute h-[400px] w-[400px] rounded-full opacity-[0.05]"
            style={{ background: "var(--peach-dark)", bottom: "-150px", left: "-100px" }}
          />
        </div>

        <div className="container-soma relative py-16 md:py-24">
          <div className="max-w-[920px]">
            <div
              className="mb-6 inline-flex items-center gap-2 rounded-full border px-3 py-1.5"
              style={{ background: "var(--soma-bg)", borderColor: "rgba(184,97,78,0.4)" }}
            >
              <Scale className="size-4 text-soma" strokeWidth={2} />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-soma">
                Resolução de disputas
              </span>
            </div>

            <h1 className="mb-6 font-title text-4xl font-bold tracking-tighter text-gray-900 md:text-5xl lg:text-[64px] leading-[1.05]">
              Outras ferramentas terminam onde
              <br />
              <span className="text-soma">o problema começa</span>.
            </h1>

            <p className="mb-8 text-lg leading-relaxed text-gray-600 md:text-xl max-w-[760px]">
              A integração com a SOMA, nossa câmara de mediação e arbitragem,
              é o diferencial estrutural da +legal_, e faz dela o único
              ambiente de gestão de contratos no Brasil com câmara de
              resolução acoplada por design.
            </p>

            <div className="flex flex-wrap gap-3">
              <Button href="/early-access" variant="primary" size="lg">
                Entrar para o Early Access <ArrowRight className="size-4" />
              </Button>
              <Button
                href="https://somalegal.tech"
                variant="secondary"
                size="lg"
                external
                className="!border-soma/40 !text-soma hover:!bg-soma-bg"
              >
                Conhecer a câmara <ExternalLink className="size-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CONTEXTO BRASIL · 83 milhões de processos + frase do luxo */}
      <section className="border-b border-stone-200 bg-white">
        <div className="container-soma section-soma">
          <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-14">
            {/* Coluna esquerda · stat de impacto */}
            <div>
              <p className="mb-4 font-mono text-[11px] font-bold uppercase tracking-widest text-soma">
                Contexto Brasil
              </p>
              <p
                className="font-title font-extrabold leading-none tracking-tighter text-brand"
                style={{ fontSize: "clamp(72px, 9vw, 128px)" }}
              >
                83 mi
              </p>
              <p className="mt-3 font-title text-lg font-bold leading-snug text-gray-900 md:text-xl">
                de processos em curso no Brasil hoje.
              </p>
              <p className="mt-2 font-mono text-[10px] uppercase tracking-widest text-stone-500">
                Fonte · CNJ · Justiça em Números 2024
              </p>
            </div>

            {/* Coluna direita · frase do luxo */}
            <div className="rounded-2xl border-2 border-soma bg-soma-bg p-8 md:p-10">
              <p className="mb-4 font-mono text-[10px] font-bold uppercase tracking-widest text-soma">
                A leitura
              </p>
              <p className="mb-5 font-title text-2xl font-bold leading-snug tracking-tight text-gray-900 md:text-3xl">
                A judicialização não é mais solução. É fila.
                <br />
                <span className="text-soma">
                  Resolução privada deixa de ser luxo, vira necessidade.
                </span>
              </p>
              <p className="text-base leading-relaxed text-gray-700">
                Empresas com contratos B2B já não podem esperar anos por uma
                decisão judicial, nem queimar o relacionamento comercial em
                processos públicos. A câmara SOMA, acoplada à +legal_,
                resolve em meses, em sigilo, e sem precisar sair do ambiente
                onde o contrato vive.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* DIAGRAMA DO FLUXO */}
      <section className="bg-stone-50">
        <div className="container-soma section-soma">
          <div className="mb-12 max-w-[820px]">
            <p className="eyebrow mb-4 text-soma">O fluxo em 4 passos</p>
            <h2 className="h-soma mb-4">
              Da divergência à resolução, sem sair do ambiente.
            </h2>
          </div>

          <div className="overflow-x-auto pb-2">
            <div className="flex min-w-[840px] items-stretch gap-2">
              {FLUXO.map((f, i) => (
                <div key={f.num} className="flex flex-1 items-stretch">
                  <div
                    className={`flex flex-1 flex-col gap-3 rounded-2xl border-2 p-6 ${
                      i === 2
                        ? "shadow-lg"
                        : ""
                    }`}
                    style={{
                      borderColor: i === 2 ? "var(--soma)" : "var(--peach-dark)",
                      background: i === 2 ? "var(--soma-bg)" : "white"
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div
                        className="flex size-10 items-center justify-center rounded-xl text-sm font-bold text-white"
                        style={{ background: i === 2 ? "var(--soma)" : "var(--peach-dark)" }}
                      >
                        {f.num}
                      </div>
                      {i === 2 && (
                        <span className="rounded-full bg-white px-2.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-widest text-soma">
                          Acoplada
                        </span>
                      )}
                    </div>
                    <h3
                      className="font-title text-base font-bold leading-tight"
                      style={{ color: i === 2 ? "var(--soma)" : "var(--peach-dark)" }}
                    >
                      {f.label}
                    </h3>
                    <p className="text-xs leading-relaxed text-gray-700">
                      {f