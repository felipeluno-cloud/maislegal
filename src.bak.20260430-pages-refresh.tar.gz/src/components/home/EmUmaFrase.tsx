import { FileText, Activity, Scale } from "lucide-react";

const PILARES_RAPIDOS = [
  {
    icon: FileText,
    label: "Ambiente compartilhado",
    sub: "as duas partes na mesma versão",
    color: "var(--peach-dark)"
  },
  {
    icon: Activity,
    label: "Monitoramento ativo",
    sub: "alertas, obrigações, aditivos",
    color: "var(--brand)"
  },
  {
    icon: Scale,
    label: "Câmara acoplada",
    sub: "mediação SOMA quando trava",
    color: "var(--soma)"
  }
];

export function EmUmaFrase() {
  return (
    <section className="relative bg-white">
      <div className="container-soma py-16 md:py-20">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[1.1fr_1fr] lg:gap-14">
          {/* Esquerda · resposta direta */}
          <div>
            <p className="mb-5 font-mono text-[11px] font-bold uppercase tracking-widest text-stone-500">
              +legal_ em uma frase
            </p>

            <h2 className="mb-6 font-title text-3xl font-bold leading-[1.12] tracking-tight text-gray-900 md:text-[40px] lg:text-[44px]">
              É o ambiente onde os contratos da sua empresa vivem do rascunho à resolução.
            </h2>

            <p className="mb-3 text-lg leading-relaxed text-gray-700">
              Sem perder versão, sem perder histórico, sem virar processo público.
            </p>

            <p className="text-lg leading-relaxed text-gray-700">
              Não substitui as ferramentas que você já usa. Atravessa elas.
            </p>
          </div>

          {/* Direita · 3 colunas que a +legal_ combina */}
          <div className="rounded-2xl border border-stone-200 bg-stone-50 p-6 md:p-7">
            <p className="mb-5 font-mono text-[10px] font-bold uppercase tracking-widest text-stone-500">
              O que ela combina
            </p>

            <div className="space-y-4">
              {PILARES_RAPIDOS.map((p) => {
                const Icon = p.icon;
                return (
                  <div
                    key={p.label}
                    className="flex items-start gap-4 rounded-xl border border-stone-200 bg-white p-4"
                  >
                    <div
                      className="flex size-10 shrink-0 items-center justify-center rounded-lg"
                      style={{ background: `${p.color}14` }}
                    >
                      <Icon className="size-5" strokeWidth={1.6} style={{ color: p.color }} />
                    </div>
                    <div>
                      <p
                        className="font-title text-[15px] font-bold leading-tight text-gray-900"
                      >
                        {p.label}
                      </p>
                      <p className="mt-0.5 text-[13px] leading-snug text-gray-600">
                        {p.sub}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
