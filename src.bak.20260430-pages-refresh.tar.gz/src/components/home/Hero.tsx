import { ArrowRight } from "lucide-react";
import { Button } from "@/components/base/Button";

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-stone-200 bg-white">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div
          className="absolute h-[700px] w-[700px] rounded-full opacity-[0.04]"
          style={{ background: "var(--brand)", top: "-200px", right: "-150px" }}
        />
        <div
          className="absolute h-[300px] w-[300px] rounded-full opacity-[0.05]"
          style={{ background: "var(--peach-dark)", bottom: "-80px", left: "-60px" }}
        />
        <svg
          className="absolute inset-0 h-full w-full opacity-[0.025]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path
                d="M 40 0 L 0 0 0 40"
                fill="none"
                stroke="currentColor"
                strokeWidth="0.5"
                className="text-brand"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="container-soma relative py-16 md:py-24 lg:py-28">
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          {/* COLUNA ESQUERDA · narrativa */}
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand-tint px-3 py-1.5">
              <span className="size-1.5 animate-pulse rounded-full bg-brand" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
                Gestão de contratos +legal_
              </span>
            </div>

            {/* Headline com hierarquia melhor entre as 2 frases */}
            <h1 className="mb-8 font-title font-bold tracking-tighter">
              <span className="block text-2xl font-medium text-stone-400 md:text-3xl lg:text-[34px]">
                Fechar um bom contrato é legal.
              </span>
              <span className="mt-2 block text-[34px] leading-[1.05] text-gray-900 md:text-[44px] lg:text-[56px]">
                Ver o combinado funcionar é{" "}
                <span className="text-brand">+legal_</span>.
              </span>
            </h1>

            <p className="mb-8 max-w-[540px] text-lg leading-relaxed text-gray-600">
              Um ambiente colaborativo onde os contratos vivem do rascunho à
              resolução, com gestão contínua das obrigações e aditivos. E
              quando uma disputa acontece, a câmara SOMA está acoplada à
              plataforma, para mediação e arbitragem.
            </p>

            <div className="flex flex-wrap gap-3">
              <Button href="/early-access" variant="primary" size="lg">
                Entrar para o Early Access <ArrowRight className="size-4" />
              </Button>
              <Button href="/como-funciona" variant="secondary" size="lg">
                Ver como funciona
              </Button>
            </div>
          </div>

          {/* COLUNA DIREITA · ilustração marcante */}
          <div className="relative hidden lg:block">
            <HeroIllustration />
          </div>
        </div>
      </div>
    </section>
  );
}

// Ilustração marcante: ciclo do contrato + câmara SOMA acoplada
// Sentido de leitura: SOMA bottom-left → RASCUNHO → ASSINATURA → MONITORAR → ADITIVOS → volta SOMA
function HeroIllustration() {
  const CX = 250;
  const CY = 250;
  const R = 175;

  // 5 posições de pentagon · index 0 = top, sentido horário
  // i=0 top · i=1 top-right · i=2 bottom-right · i=3 bottom-left · i=4 top-left
  const angle = (i: number) => -Math.PI / 2 + (i * 2 * Math.PI) / 5;
  const pos = (i: number) => ({
    x: CX + R * Math.cos(angle(i)),
    y: CY + R * Math.sin(angle(i))
  });

  // Estágios do ciclo · em ordem de fluxo
  // SOMA fica no bottom-left (posição visual i=3)
  // O ciclo do contrato corre 01 → 02 → 03 → 04 começando do top-left
  const STAGES = [
    { i: 4, num: "01", label: "RASCUNHO", color: "var(--brand)" },
    { i: 0, num: "02", label: "ASSINATURA", color: "var(--brand)" },
    { i: 1, num: "03", label: "MONITORAR", color: "var(--peach-dark)" },
    { i: 2, num: "04", label: "ADITIVOS", color: "var(--peach-dark)" }
  ];

  const SOMA_POS_INDEX = 3; // bottom-left

  return (
    <div className="relative mx-auto aspect-square w-full max-w-[500px]">
      <svg
        viewBox="0 0 500 540"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-full"
        aria-hidden="true"
      >
        <defs>
          <marker
            id="arrow-brand"
            viewBox="0 0 10 10"
            refX="6"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 8 5 L 0 10 z" fill="var(--brand)" />
          </marker>
          <marker
            id="arrow-peach"
            viewBox="0 0 10 10"
            refX="6"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 8 5 L 0 10 z" fill="var(--peach-dark)" />
          </marker>
          <marker
            id="arrow-soma"
            viewBox="0 0 10 10"
            refX="6"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 8 5 L 0 10 z" fill="var(--soma)" />
          </marker>
        </defs>

        {/* ═════ Anel principal · grosso (Rafael pediu mais impacto) ═════ */}
        <circle
          cx={CX}
          cy={CY}
          r={R}
          fill="none"
          stroke="var(--brand)"
          strokeWidth="2.6"
          opacity="0.18"
        />

        {/* ═════ Arcos do fluxo · setas seguindo o ciclo ═════ */}
        {STAGES.map((s, idx) => {
          const next = STAGES[(idx + 1) % STAGES.length];
          const startA = angle(s.i);
          const endA = angle(next.i);

          // Calcula direção mais curta · sempre sentido horário visual
          let endAdj = endA;
          while (endAdj <= startA) endAdj += 2 * Math.PI;

          const buffer = 0.22;
          const sx = CX + R * Math.cos(startA + buffer);
          const sy = CY + R * Math.sin(startA + buffer);
          const ex = CX + R * Math.cos(endAdj - buffer);
          const ey = CY + R * Math.sin(endAdj - buffer);

          const color = next.color;
          const arrowId =
            color === "var(--brand)" ? "url(#arrow-brand)" : "url(#arrow-peach)";

          return (
            <path
              key={`arc-${idx}`}
              d={`M ${sx} ${sy} A ${R} ${R} 0 0 1 ${ex} ${ey}`}
              fill="none"
              stroke={color}
              strokeWidth="2.4"
              strokeLinecap="round"
              opacity="0.7"
              markerEnd={arrowId}
            />
          );
        })}

        {/* ═════ Linha tracejada saindo do ciclo para SOMA · "se precisar" ═════ */}
        {(() => {
          const aditivos = pos(2); // bottom-right
          const soma = pos(SOMA_POS_INDEX); // bottom-left
          const dx = soma.x - aditivos.x;
          const dy = soma.y - aditivos.y;
          const len = Math.sqrt(dx * dx + dy * dy);
          const ux = dx / len;
          const uy = dy / len;
          // Distância do contorno
          const startBuffer = 36;
          const endBuffer = 42;
          const sx = aditivos.x + ux * startBuffer;
          const sy = aditivos.y + uy * startBuffer;
          const ex = soma.x - ux * endBuffer;
          const ey = soma.y - uy * endBuffer;

          