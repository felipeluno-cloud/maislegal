import { Activity, Check } from "lucide-react";

const O_QUE_MUDA = [
  "Painel com todos os contratos, status, prazos e SLAs em uma tela.",
  "Alertas automáticos 90, 60 e 30 dias antes de cada vencimento.",
  "Aditivos formalizados dentro da plataforma, com aprovação registrada.",
  "Quando alguém sai do time, o contexto fica."
];

const ETAPAS = [
  { num: "01", label: "Rascunho" },
  { num: "02", label: "Negociação" },
  { num: "03", label: "Assinatura" },
  { num: "04", label: "Cumprimento" },
  { num: "05", label: "Aditivos" },
  { num: "06", label: "Resolução" }
];

export function Pilar02RascunhoResolucao() {
  return (
    <section
      className="relative"
      style={{ background: "var(--brand-tint)" }}
    >
      <div className="container-soma section-soma">
        {/* Header do pilar */}
        <div className="mb-12 max-w-[860px]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-brand/30 bg-white px-3 py-1.5">
            <span className="font-mono text-[10px] font-bold tracking-widest text-brand">
              PILAR 02
            </span>
            <span className="h-3 w-px bg-brand/30" />
            <Activity className="size-4 text-brand" strokeWidth={2} />
            <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-brand">
              Para Diretoras de Operações
            </span>
          </div>

          <h2 className="h-soma mb-4">
            Você gerencia 80 contratos. Os prazos chegam antes do problema, não depois.
          </h2>

          <p className="mb-3 text-lg leading-relaxed text-gray-700">
            O contrato não termina quando todo mundo assina. Ele começa a viver. Cada cláusula tem um prazo, cada obrigação tem um responsável, e cada renovação tem uma janela que não pode passar batida.
          </p>

          <p className="text-lg leading-relaxed text-gray-700">
            Você abre a +legal_ pela manhã e vê o que vence essa semana, o que está em risco, e o que precisa de decisão sua. Os alertas chegam antes do problema, não depois.
          </p>
        </div>

        {/* Visual · linha do tempo do contrato */}
        <div className="mb-12">
          <LinhaDoTempo />
        </div>

        {/* Layout cenário + lista */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 lg:gap-8">
          {/* Cenário típico */}
          <div className="rounded-2xl border-2 border-brand bg-white p-6 md:p-7">
            <div className="mb-3 flex items-center gap-2">
              <span className="font-mono text-[10px] font-bold uppercase tracking-widest text-brand">
                Cenário típico
              </span>
              <span className="h-3 w-px bg-brand/30" />
              <span className="font-mono text-[10px] font-bold uppercase tracking-widest text-brand">
                Diretora de Operações
              </span>
            </div>

            <p className="font-title text-base leading-relaxed text-gray-900 md:text-lg">
              Empresa de outsourcing com <strong className="font-extrabold">80 contratos ativos</strong>. Time de <strong className="font-extrabold">4 pessoas</strong> operando. Fornecedores em vários estados, SLAs específicos por contrato, datas de renovação espalhadas pelo ano.
            </p>
            <p className="mt-3 font-title text-base leading-relaxed text-gray-900 md:text-lg">
              A planilha existe. Mas alguém precisa lembrar de olhar.
            </p>
          </div>

          {/* O que muda na prática */}
          <div className="rounded-2xl border border-brand-light bg-white p-6 md:p-7">
            <p className="mb-4 font-mono text-[10px] font-bold uppercase tracking-widest text-brand">
              O que muda na prática
            </p>
            <ul className="flex flex-col gap-3">
              {O_QUE_MUDA.map(item => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-brand-tint">
                    <Check className="size-3 text-brand" strokeWidth={3} />
                  </span>
                  <span className="text-[15px] leading-snug text-gray-700">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

// Visual · linha do tempo das 6 etapas do contrato
function LinhaDoTempo() {
  return (
    <div className="rounded-3xl border border-brand-light bg-white p-8 md:p-10">
      {/* Label superior */}
      <p className="mb-6 text-center font-mono text-[10px] font-bold uppercase tracking-widest text-brand">
        Ciclo de vida do contrato, todo no mesmo ambiente
      </p>

      {/* Versão desktop · linha horizontal */}
      <div className="hidden md:block">
        <svg
          viewBox="0 0 1100 160"
          xmlns="http://www.w3.org/2000/svg"
          className="h-auto w-full"
          aria-hidden="true"
        >
          {/* Linha contínua de fundo */}
          <line
            x1="80"
            y1="80"
            x2="1020"
            y2="80"
            stroke="var(--brand)"
            strokeWidth="2.5"
            opacity="0.18"
          />

          {/* 6 etapas */}
          {ETAPAS.map((etapa, i) => {
            const x = 80 + i * 188;
            return (
              <g key={etapa.num} transform={`translate(${x} 80)`}>
                {/* Círculo da etapa */}
                <circle
                  r="22"
                  fill="white"
                  stroke="var(--brand)"
                  strokeWidth="2"
                />
                <text
                  x="0"
                  y="4"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="11"
                  fontWeight="700"
                  fill="var(--brand)"
                  textAnchor="middle"
                  letterSpacing="0.5"
                >
                  {etapa.num}
                </text>

                {/* Label embaixo */}
                <text
                  x="0"
                  y="72"
                  fontFamily="Barlow, sans-serif"
                  fontSize="14"
                  fontWeight="700"
                  fill="var(--brand)"
                  textAnchor="middle"
                >
                  {etapa.label}
                </text>

                {/* Ponto pequeno acima · alerta/atividade */}
                <circle
                  cx="0"
                  cy="-46"
                  r="3"
                  fill="var(--peach-dark)"
                  opacity={i === 3 || i === 4 ? "1" : "0.35"}
                />
              </g>
            );
          })}

          {/* Faixa "cuidado contínuo" */}
          <rect
            x="80"
            y="105"
            width="940"
            height="22"
            rx="11"
            fill="var(--brand-tint)"
            stroke="var(--brand-light)"
            strokeWidth="1"
          />
          <text
            x="550"
            y="120"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--brand)"
            textAnchor="middle"
            letterSpacing="2"
          >
            CUIDADO CONTÍNUO · ALERTAS · APROVAÇÕES · HISTÓRICO
          </text>
        </svg>
      </div>

      {/* Versão mobile · vertical */}
      <div className="flex flex-col gap-3 md:hidden">
        {ETAPAS.map(etapa => (
          <div
            key={etapa.num}
            className="flex items-center gap-3 rounded-lg border border-brand-light bg-brand-tint px-4 py-3"
          >
            <span className="flex size-8 shrink-0 items-center justify-center rounded-full border