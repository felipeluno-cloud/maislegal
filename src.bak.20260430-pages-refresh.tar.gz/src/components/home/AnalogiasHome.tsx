import Link from "next/link";
import { ArrowRight, Sprout } from "lucide-react";

export function AnalogiasHome() {
  return (
    <section className="bg-stone-50">
      <div className="container-soma section-soma">
        <div className="mb-12 max-w-[860px]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-stone-300 bg-white px-3 py-1.5">
            <Sprout className="size-4 text-brand" strokeWidth={2} />
            <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-stone-700">
              A analogia que define o produto
            </span>
          </div>
          <h2 className="h-soma mb-4">
            O contrato como ferramenta viva.
          </h2>
          <p className="text-lg leading-relaxed text-gray-600">
            Contratos são ferramentas vivas, que se adaptam, se alteram, e
            se moldam em torno dos relacionamentos comerciais. Não existem
            para ficar parados num arquivo, e sim para acompanhar o que
            muda no negócio e garantir que o relacionamento continue
            prosperando.
          </p>
        </div>

        {/* Card editorial em destaque · ilustração + texto + frase âncora */}
        <div className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-[1.1fr_1fr]">
          {/* Visual · ilustração de "vida" do contrato */}
          <div className="overflow-hidden rounded-3xl bg-white p-10 ring-1 ring-stone-200 lg:p-14">
            <VisualFerramentaViva />
          </div>

          {/* Texto · frase âncora + expansão + CTA */}
          <div className="flex flex-col justify-center rounded-3xl border-2 border-brand bg-white p-8 md:p-10">
            <p className="mb-4 font-mono text-[10px] font-bold uppercase tracking-widest text-brand">
              A ideia em uma frase
            </p>
            <p className="mb-6 font-title text-2xl font-bold leading-snug tracking-tight text-gray-900 md:text-3xl">
              O contrato vivo se molda ao relacionamento.
              <br />
              <span className="text-brand">
                O contrato morto prende o relacionamento.
              </span>
            </p>
            <p className="mb-7 text-base leading-relaxed text-gray-700">
              Quando o cliente pede mais entregas, o sócio sai, o mercado
              pressiona o preço, ou um combinado verbal precisa virar
              oficial, o contrato vivo se ajusta dentro do mesmo ambiente,
              sem refazer tudo do zero. Cada movimento fica registrado, e
              o relacionamento comercial segue protegido pela própria
              estrutura do contrato.
            </p>
            <Link
              href="/explainers#explainer-04"
              className="inline-flex items-center gap-2 self-start rounded-lg bg-brand px-5 py-3 font-mono text-xs font-bold uppercase tracking-widest text-white transition-all hover:gap-3 hover:bg-brand-mid"
            >
              Ver o explainer completo <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

// Ilustração · documento "vivo" com pulse + brotinhos de adaptação
function VisualFerramentaViva() {
  return (
    <svg
      viewBox="0 0 480 380"
      xmlns="http://www.w3.org/2000/svg"
      className="h-auto w-full"
      aria-hidden="true"
    >
      {/* Halo respirando atrás do contrato */}
      <circle cx="240" cy="190" r="140" fill="var(--brand)" opacity="0.06">
        <animate
          attributeName="r"
          values="140;160;140"
          dur="4s"
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0.06;0.02;0.06"
          dur="4s"
          repeatCount="indefinite"
        />
      </circle>

      {/* Documento central */}
      <g transform="translate(240 190)">
        <rect
          x="-90"
          y="-110"
          width="180"
          height="220"
          rx="12"
          fill="white"
          stroke="var(--brand)"
          strokeWidth="2.4"
        />

        {/* Header do contrato */}
        <rect
          x="-90"
          y="-110"
          width="180"
          height="34"
          rx="12"
          fill="var(--brand-tint)"
        />
        <rect x="-90" y="-92" width="180" height="16" fill="var(--brand-tint)" />

        {/* Live dot pulsando */}
        <circle cx="-74" cy="-90" r="4" fill="var(--brand)">
          <animate
            attributeName="opacity"
            values="1;0.3;1"
            dur="1.6s"
            repeatCount="indefinite"
          />
        </circle>
        <text
          x="-62"
          y="-86"
          fontFamily="JetBrains Mono, monospace"
          fontSize="9"
          fontWeight="700"
          fill="var(--brand)"
          letterSpacing="1.5"
        >
          CONTRATO ATIVO · VIVO
        </text>

        {/* Linhas de texto */}
        {[-58, -46, -34, -22, -10, 4, 16, 28, 40].map((y, idx) => (
          <line
            key={idx}
            x1="-74"
            y1={y}
            x2={idx % 3 === 0 ? "70" : idx % 3 === 1 ? "60" : "50"}
            y2={y}
            stroke="var(--brand)"
            strokeWidth="1.1"
            opacity="0.28"
            strokeLinecap="round"
          />
        ))}

        {/* Aditivo recente · highlight peach */}
        <rect
          x="-76"
          y="50"
          width="120"
          height="12"
          rx="2"
          fill="var(--