import { ArrowRight, Scale, Check } from "lucide-react";
import { Button } from "@/components/base/Button";

// Terracota SOMA · permitido aqui pela regra de co-presença (pilar é SOMA)
const TERRA = "#B8614E";
const TERRA_BG = "#F7EFED";
const TERRA_LIGHT = "rgba(184, 97, 78, 0.22)";

const O_QUE_MUDA = [
  "Histórico completo do contrato disponível na hora, sem reconstrução manual.",
  "Abertura de procedimento na câmara SOMA com um clique.",
  "Mediação primeiro, com crédito do honorário se virar arbitragem.",
  "Resolução confidencial. Sem desgaste público."
];

export function Pilar03CamaraAcoplada() {
  return (
    <section className="relative overflow-hidden bg-white">
      {/* Decorativo de fundo · sutil */}
      <div className="pointer-events-none absolute inset-0">
        <div
          className="absolute h-[600px] w-[600px] rounded-full opacity-[0.04]"
          style={{ background: TERRA, top: "-180px", right: "-200px" }}
        />
        <div
          className="absolute h-[400px] w-[400px] rounded-full opacity-[0.05]"
          style={{ background: "var(--soma)", bottom: "-160px", left: "-160px" }}
        />
      </div>

      <div className="container-soma section-soma relative">
        {/* Header do pilar */}
        <div className="mb-12 max-w-[920px]">
          <div
            className="mb-5 inline-flex items-center gap-2 rounded-full border bg-white px-3 py-1.5"
            style={{ borderColor: TERRA_LIGHT }}
          >
            <span
              className="font-mono text-[10px] font-bold tracking-widest"
              style={{ color: TERRA }}
            >
              PILAR 03
            </span>
            <span
              className="h-3 w-px"
              style={{ background: TERRA_LIGHT }}
            />
            <Scale className="size-4" strokeWidth={2} style={{ color: TERRA }} />
            <span
              className="font-mono text-[11px] font-bold uppercase tracking-widest"
              style={{ color: TERRA }}
            >
              Para Escritórios de Advocacia
            </span>
          </div>

          <h2 className="h-soma mb-4">
            Você abre o caso e o histórico está pronto. Não reconstrói por 3 semanas.
          </h2>

          <p className="mb-3 text-lg leading-relaxed text-gray-700">
            A maioria das ferramentas de gestão de contratos para exatamente onde o problema costuma começar. A +legal_ segue adiante, com a câmara <span style={{ color: "var(--soma)" }}>SOMA</span> acoplada para mediação e arbitragem.
          </p>

          <p className="text-lg leading-relaxed text-gray-700">
            Quando a disputa chega, o histórico inteiro do contrato já está disponível na câmara, sem export, sem reconstrução. A resolução é sigilosa, acontece em meses, e dispensa a ida ao judiciário.
          </p>
        </div>

        {/* Fluxo SOMA · visual destacado */}
        <div className="mb-14">
          <FluxoSOMA />
        </div>

        {/* Layout cenário + lista */}
        <div className="mb-12 grid grid-cols-1 gap-6 lg:grid-cols-2 lg:gap-8">
          {/* Cenário típico */}
          <div
            className="rounded-2xl border-2 p-6 md:p-7"
            style={{ borderColor: TERRA, background: TERRA_BG }}
          >
            <div className="mb-3 flex items-center gap-2">
              <span
                className="font-mono text-[10px] font-bold uppercase tracking-widest"
                style={{ color: TERRA }}
              >
                Cenário típico
              </span>
              <span
                className="h-3 w-px"
                style={{ background: TERRA_LIGHT }}
              />
              <span
                className="font-mono text-[10px] font-bold uppercase tracking-widest"
                style={{ color: TERRA }}
              >
                Escritório de advocacia
              </span>
            </div>

            <p className="font-title text-base leading-relaxed text-gray-900 md:text-lg">
              Escritório de contencioso recebe um cliente em disputa por descumprimento de prazo. Contrato assinado há <strong className="font-extrabold">18 meses</strong>. Houve um aditivo verbal em reunião, e as versões das partes têm diferenças que ninguém explica.
            </p>
            <p className="mt-3 font-title text-base leading-relaxed text-gray-900 md:text-lg">
              <strong className="font-extrabold">Três semanas</strong> para reconstruir o histórico antes da arbitragem começar.
            </p>
          </div>

          {/* O que muda na prática */}
          <div className="rounded-2xl border border-stone-200 bg-white p-6 md:p-7">
            <p
              className="mb-4 font-mono text-[10px] font-bold uppercase tracking-widest"
              style={{ color: TERRA }}
            >
              O que muda na prática
            </p>
            <ul className="flex flex-col gap-3">
              {O_QUE_MUDA.map(item => (
                <li key={item} className="flex items-start gap-3">
                  <span
                    className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full"
                    style={{ background: TERRA_BG }}
                  >
                    <Check
                      className="size-3"
                      strokeWidth={3}
                      style={{ color: TERRA }}
                    />
                  </span>
                  <span className="text-[15px] leading-snug text-gray-700">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* CTA único · continuidade dentro do site */}
        <div className="flex justify-center">
          <Button
            href="/resolucao-de-disputas"
            variant="primary"
            size="lg"
            className="!border-soma !bg-soma hover:!bg-soma/90"
          >
            Como a integração funciona <ArrowRight className="size-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}

// Fluxo · contrato → divergência → câmara → mediação → resolução
function FluxoSOMA() {
  return (
    <div
      className="mx-auto max-w-[1100px] rounded-3xl border bg-white p-8 md:p-10"
      style={{ borderColor: "rgba(184,97,78,0.18)" }}
    >
      <p
        className="mb-6 text-center font-mono text-[10px] font-bold uppercase tracking-widest"
        style={{ color: "var(--soma)" }}
      >
        Caminho da resolução, sem sair do mesmo ambiente
      </p>

      <svg
        viewBox="0 0 1100 220"
        xmlns="http://www.w3.org/2000/svg"
        className="h-auto w-full"
        aria-hidden="true"
      >
        {/* Linha tracejada conectando tudo */}
        <line
          x1="100"
          y1="110"
          x2="1010"
          y2="110"
          stroke="var(--soma)"
          strokeWidth="2"
          strokeDasharray="6 4"
          opacity="0.35"
        />

        {/* 01 · Contrato ativo */}
        <g transform="translate(100 110)">
          <circle r="60" fill="white" stroke="var(--brand)" strokeWidth="2" />
          <rect
            x="-22"
            y="-26"
            width="44"
            height="52"
            rx="4"
            fill="none"
            stroke="var(--brand)"
            strokeWidth="1.4"
          />
          {[-14, -6, 2, 10].map(y => (
            <line
              key={y}
              x1="-15"
              y1={y}
              x2={y === 10 ? 11 : 15}
              y2={y}
              stroke="var(--brand)"
              strokeWidth="1"
              opacity="0.5"
              strokeLinecap="round"
            />
          ))}
          <text
            x="0"
            y="90"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11"
            fontWeight="700"
            fill="var(--brand)"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            CONTRATO ATIVO
          </text>
          <text
            x="0"
            y="-80"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--brand)"
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.5"
          >
            01
          </text>
        </g>

        {/* Seta + label DIVERGÊNCIA */}
        <g transform="translate(310 110)">
          <text
            x="0"
            y="-22"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            DIVERGÊNCIA
          </text>
          <path
            d="M -8 0 L 8 0 M 4 -4 L 8 0 L 4 4"
            stroke="var(--soma)"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>

        {/* 02 · Câmara SOMA acoplada */}
        <g transform="translate(450 110)">
          <circle
            r="62"
            fill="white"
            stroke="var(--soma)"
            strokeWidth="2.5"
          />
          <path
            d="M 0 -32 L 28 -18 v 14 c 0 14 -10 22 -28 30 c -18 -8 -28 -16 -28 -30 v -14 z"
            fill="var(--soma-bg)"
            stroke="var(--soma)"
            strokeWidth="1.8"
          />
          <text
            x="0"
            y="2"
            fontFamily="Barlow, sans-serif"
            fontSize="14"
            fontWeight="800"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1"
          >
            SOMA
          </text>
          <text
            x="0"
            y="14"
            fontFamily="JetBrains Mono, monospace"
            fontSize="6"
            fontWeight="700"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1"
            opacity="0.7"
          >
            CÂMARA
          </text>
          <text
            x="0"
            y="92"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11"
            fontWeight="700"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            CÂMARA ACOPLADA
          </text>
          <text
            x="0"
            y="-82"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.5"
          >
            02
          </text>
        </g>

        {/* Seta + label MEDIAÇÃO */}
        <g transform="translate(640 110)">
          <text
            x="0"
            y="-22"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--soma)"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            MEDIAÇÃO
          </text>
          <path
            d="M -8 0 L 8 0 M 4 -4 L 8 0 L 4 4"
            stroke="var(--soma)"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>

        {/* 03 · Mediação primeiro */}
        <g transform="translate(770 110)">
          <circle
            r="55"
            fill="white"
            stroke="var(--peach-dark)"
            strokeWidth="2"
          />
          <svg x="-16" y="-16" width="32" height="32" viewBox="0 0 24 24">
            <path
              d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
              stroke="var(--peach-dark)"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          </svg>
          <text
            x="0"
            y="84"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11"
            fontWeight="700"
            fill="var(--peach-dark)"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            MEDIAÇÃO PRIMEIRO
          </text>
          <text
            x="0"
            y="-76"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill="var(--peach-dark)"
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.5"
          >
            03
          </text>
        </g>

        {/* Seta + label RESOLUÇÃO */}
        <g transform="translate(910 110)">
          <text
            x="0"
            y="-22"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill={TERRA}
            textAnchor="middle"
            letterSpacing="1.5"
          >
            RESOLUÇÃO
          </text>
          <path
            d="M -8 0 L 8 0 M 4 -4 L 8 0 L 4 4"
            stroke={TERRA}
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>

        {/* 04 · Resolvido */}
        <g transform="translate(1010 110)">
          <circle r="55" fill="white" stroke={TERRA} strokeWidth="2.5" />
          <path
            d="M -16 0 L -4 12 L 18 -10"
            fill="none"
            stroke={TERRA}
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <text
            x="0"
            y="84"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11"
            fontWeight="700"
            fill={TERRA}
            textAnchor="middle"
            letterSpacing="1.5"
          >
            EM MESES
          </text>
          <text
            x="0"
            y="-76"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10"
            fontWeight="700"
            fill={TERRA}
            textAnchor="middle"
            letterSpacing="1.5"
            opacity="0.5"
          >
            04
          </text>
        </g>
      </svg