import { Filter } from "lucide-react";

const NEGACOES = [
  {
    nao: "Plataforma de assinatura digital",
    sim: "A assinatura é uma etapa. Integramos com DocuSign, ClickSign, ZapSign.",
    icon: "signature"
  },
  {
    nao: "Substituto de advogados",
    sim: "Ferramenta para você e seus advogados trabalharem com mais informação.",
    icon: "lawyer"
  },
  {
    nao: "Inteligência artificial tomando decisões",
    sim: "Tecnologia cuida do processo. Pessoas cuidam das decisões que importam.",
    icon: "ai"
  },
  {
    nao: "Drive com nome jurídico",
    sim: "Ambiente com propósito: monitoramento, alertas, inteligência contratual.",
    icon: "drive"
  },
  {
    nao: "A câmara SOMA",
    sim: "Entidades separadas, integradas. Use uma sem a outra, ou as duas juntas.",
    icon: "chamber"
  }
];

export function OQueNaoE() {
  return (
    <section className="bg-white">
      <div className="container-soma section-soma">
        <div className="mb-12 max-w-[820px]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-stone-300 bg-stone-50 px-3 py-1.5">
            <Filter className="size-4 text-stone-600" strokeWidth={2} />
            <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-stone-700">
              Filtro
            </span>
          </div>

          <h2 className="h-soma mb-4">
            A +legal_ está perto de coisas que você já conhece. Não é nenhuma delas.
          </h2>

          <p className="text-lg leading-relaxed text-gray-700">
            Cinco ferramentas próximas, com sobreposição parcial. Saber o que a +legal_ não é ajuda a entender o que ela é.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1.1fr_1fr]">
          {/* 5 cards · ferramentas próximas, mas não iguais */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {NEGACOES.map((n, i) => (
              <div
                key={n.nao}
                className="relative overflow-hidden rounded-2xl border border-stone-200 bg-white p-5"
              >
                {/* Mini-ícone */}
                <div className="mb-4 flex h-12 items-center">
                  <NaoIcon variant={n.icon} />
                </div>

                {/* Nome com riscado */}
                <div className="mb-3">
                  <p className="relative inline-block font-title text-[15px] font-bold text-gray-900">
                    {n.nao}
                    <span
                      aria-hidden="true"
                      className="absolute left-0 right-0 top-1/2 h-px"
                      style={{
                        background: "#dc2626",
                        opacity: 0.7
                      }}
                    />
                  </p>
                </div>

                {/* Correção */}
                <p className="text-[13px] leading-relaxed text-gray-600">
                  {n.sim}
                </p>

                {/* Numeração discreta */}
                <span
                  className="pointer-events-none absolute right-3 top-3 font-mono text-[10px] font-bold tracking-widest text-stone-400"
                  aria-hidden="true"
                >
                  0{i + 1}
                </span>
              </div>
            ))}

            {/* Sexto slot · seta de